#include "JsonStore.h"

#include "../domain/AppData.h"

#include <QDir>
#include <QFile>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QSaveFile>
#include <QStandardPaths>

// ---- serialization helpers (file-local) -------------------------------------
// `static` at file scope = visible only inside this .cpp. These helpers are
// private machinery of the storage layer; nothing else should ever call them.
// Each pair (toJson / fromJson) is small and boring on purpose — boring code
// is what you want at the persistence boundary, where bugs eat user data.

// Timestamps are stored as ISO-8601 strings ("2026-07-03T14:05:00") —
// human-readable in the file and unambiguous to parse back.
static QString   dtToJson(const QDateTime& dt) { return dt.toString(Qt::ISODate); }
static QDateTime dtFromJson(const QString& s)  { return QDateTime::fromString(s, Qt::ISODate); }

static QJsonObject toJson(const Category& c)
{
    return QJsonObject{
        {"id",    c.id},
        {"name",  c.name},
        {"color", c.color.name()}, // "#4C6FE0" — readable, portable
    };
}

static Category categoryFromJson(const QJsonObject& o)
{
    Category c;
    c.id    = o["id"].toString();
    c.name  = o["name"].toString();
    c.color = QColor(o["color"].toString());
    return c;
}

static QJsonObject toJson(const Activity& a)
{
    return QJsonObject{
        {"id",         a.id},
        {"name",       a.name},
        {"categoryId", a.categoryId},
    };
}

static Activity activityFromJson(const QJsonObject& o)
{
    Activity a;
    a.id         = o["id"].toString();
    a.name       = o["name"].toString();
    a.categoryId = o["categoryId"].toString();
    return a;
}

static QJsonObject toJson(const Segment& s)
{
    return QJsonObject{
        {"kind",  s.kind == SegmentKind::Focus ? "focus" : "break"},
        {"start", dtToJson(s.start)},
        {"end",   dtToJson(s.end)},
    };
}

static Segment segmentFromJson(const QJsonObject& o)
{
    Segment s;
    s.kind  = o["kind"].toString() == "break" ? SegmentKind::Break
                                              : SegmentKind::Focus;
    s.start = dtFromJson(o["start"].toString());
    s.end   = dtFromJson(o["end"].toString());
    return s;
}

static QJsonObject toJson(const Event& e)
{
    QJsonArray segments;
    for (const Segment& s : e.segments)
        segments.append(toJson(s));

    return QJsonObject{
        {"id",           e.id},
        {"date",         e.date.toString(Qt::ISODate)},
        {"startMinutes", e.plannedStartMinutes},
        {"endMinutes",   e.plannedEndMinutes},
        {"activityId",   e.activityId},
        {"note",         e.note},
        {"segments",     segments},
    };
}

static Event eventFromJson(const QJsonObject& o)
{
    Event e;
    e.id                  = o["id"].toString();
    e.date                = QDate::fromString(o["date"].toString(), Qt::ISODate);
    e.plannedStartMinutes = o["startMinutes"].toInt();
    e.plannedEndMinutes   = o["endMinutes"].toInt();
    e.activityId          = o["activityId"].toString();
    e.note                = o["note"].toString();
    for (const QJsonValue& v : o["segments"].toArray())
        e.segments.append(segmentFromJson(v.toObject()));
    return e;
}

// ---- JsonStore ----------------------------------------------------------------

JsonStore::JsonStore(QString filePath)
    : m_filePath(std::move(filePath))
{
}

QString JsonStore::defaultFilePath()
{
    const QString dir =
        QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
    QDir().mkpath(dir); // ensure the folder exists before first save
    return dir + QStringLiteral("/data.json");
}

bool JsonStore::load(AppData& data)
{
    m_error.clear();

    QFile file(m_filePath);
    if (!file.exists())
        return false; // first run — not an error, just nothing to load yet

    if (!file.open(QIODevice::ReadOnly)) {
        m_error = QStringLiteral("Could not open %1: %2")
                      .arg(m_filePath, file.errorString());
        return false;
    }

    QJsonParseError parseError;
    const QJsonDocument doc = QJsonDocument::fromJson(file.readAll(), &parseError);
    if (doc.isNull()) {
        m_error = QStringLiteral("Data file is not valid JSON: %1")
                      .arg(parseError.errorString());
        return false;
    }

    const QJsonObject root = doc.object();

    QVector<Category> categories;
    for (const QJsonValue& v : root["categories"].toArray())
        categories.append(categoryFromJson(v.toObject()));

    QVector<Activity> activities;
    for (const QJsonValue& v : root["activities"].toArray())
        activities.append(activityFromJson(v.toObject()));

    QVector<Event> events;
    for (const QJsonValue& v : root["events"].toArray())
        events.append(eventFromJson(v.toObject()));

    std::optional<RunningState> running;
    if (root.contains("running")) {
        const QJsonObject r = root["running"].toObject();
        RunningState state;
        state.eventId  = r["eventId"].toString();
        state.kind     = r["kind"].toString() == "break" ? SegmentKind::Break
                                                         : SegmentKind::Focus;
        state.start    = dtFromJson(r["start"].toString());
        state.lastSeen = dtFromJson(r["lastSeen"].toString());
        running = state;
    }

    data.resetFrom(std::move(categories), std::move(activities),
                   std::move(events), std::move(running));
    return true;
}

bool JsonStore::save(const AppData& data)
{
    m_error.clear();

    QJsonArray categories;
    for (const Category& c : data.categories())
        categories.append(toJson(c));

    QJsonArray activities;
    for (const Activity& a : data.activities())
        activities.append(toJson(a));

    QJsonArray events;
    for (const Event& e : data.events())
        events.append(toJson(e));

    QJsonObject root{
        // A version number from day one: when the format evolves, the loader
        // can tell old files from new and migrate instead of choking.
        {"version",    1},
        {"categories", categories},
        {"activities", activities},
        {"events",     events},
    };

    if (data.running()) {
        const RunningState& r = *data.running();
        root["running"] = QJsonObject{
            {"eventId",  r.eventId},
            {"kind",     r.kind == SegmentKind::Focus ? "focus" : "break"},
            {"start",    dtToJson(r.start)},
            {"lastSeen", dtToJson(r.lastSeen)},
        };
    }

    // THE RELIABILITY RULE (Supplementary Spec): "a crash during a save must
    // not corrupt the existing data — write safely (write-then-replace)."
    // QSaveFile IS that rule, shipped with Qt: it writes to a hidden
    // temporary file and only on commit() atomically renames it over the
    // real one. Kill the process mid-save and yesterday's file is intact.
    // A plain QFile would truncate the file first and could leave you with
    // half a file — with your whole history in it.
    QSaveFile file(m_filePath);
    if (!file.open(QIODevice::WriteOnly)) {
        m_error = QStringLiteral("Could not write %1: %2")
                      .arg(m_filePath, file.errorString());
        return false;
    }

    // Indented = human-readable on disk; a few wasted bytes buy easy
    // debugging, the very reason we chose JSON (design-doc §4).
    file.write(QJsonDocument(root).toJson(QJsonDocument::Indented));

    if (!file.commit()) {
        m_error = QStringLiteral("Could not commit save to %1: %2")
                      .arg(m_filePath, file.errorString());
        return false;
    }
    return true;
}
