#include "Stats.h"

namespace stats
{

Totals eventTotals(const Event& event)
{
    Totals t;
    for (const Segment& s : event.segments) {
        if (s.kind == SegmentKind::Focus)
            t.focusSeconds += s.seconds();
        else
            t.breakSeconds += s.seconds();
    }
    return t;
}

PeriodSummary summarize(const AppData& data, QDate from, QDate to)
{
    PeriodSummary summary;

    // Pre-create one byDay bucket per day so charts get a bar even for
    // silent days — a week chart with missing weekdays would be confusing.
    for (QDate d = from; d <= to; d = d.addDays(1))
        summary.byDay.append({d, Totals{}});

    for (const Event& e : data.events()) {
        if (e.date < from || e.date > to)
            continue;

        const Totals t = eventTotals(e);
        if (t.total() == 0)
            continue; // planned but never tracked — nothing to count yet

        summary.totals.focusSeconds += t.focusSeconds;
        summary.totals.breakSeconds += t.breakSeconds;

        // Attribute the tracked time to the Activity's life area. The
        // chain Event -> Activity -> Category is the "reference, don't
        // copy" design paying rent: recategorise an Activity and every
        // historical chart re-attributes itself, automatically.
        if (const Activity* a = data.activityById(e.activityId))
            summary.byCategory[a->categoryId] += t.total();

        const qint64 dayIndex = from.daysTo(e.date);
        if (dayIndex >= 0 && dayIndex < summary.byDay.size()) {
            summary.byDay[dayIndex].second.focusSeconds += t.focusSeconds;
            summary.byDay[dayIndex].second.breakSeconds += t.breakSeconds;
        }
    }
    return summary;
}

PeriodSummary summarizeDay(const AppData& data, QDate day)
{
    return summarize(data, day, day);
}

PeriodSummary summarizeWeek(const AppData& data, QDate anyDayInWeek)
{
    // Qt: Monday==1 .. Sunday==7, so this lands on the week's Monday.
    const QDate monday = anyDayInWeek.addDays(1 - anyDayInWeek.dayOfWeek());
    return summarize(data, monday, monday.addDays(6));
}

PeriodSummary summarizeMonth(const AppData& data, QDate anyDayInMonth)
{
    const QDate first(anyDayInMonth.year(), anyDayInMonth.month(), 1);
    return summarize(data, first, first.addDays(first.daysInMonth() - 1));
}

QString formatSeconds(qint64 seconds)
{
    seconds = qMax<qint64>(0, seconds);
    const qint64 minutes = seconds / 60;
    const qint64 hours   = minutes / 60;
    if (hours > 0)
        return QStringLiteral("%1h %2m").arg(hours).arg(minutes % 60, 2, 10, QChar('0'));
    if (minutes > 0)
        return QStringLiteral("%1m").arg(minutes);
    return QStringLiteral("%1s").arg(seconds);
}

} // namespace stats
