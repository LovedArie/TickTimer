#include "AppData.h"

#include "Ids.h"

#include <algorithm> // std::sort, std::remove_if — the STL, not hand-rolled loops

AppData::AppData(QObject* parent)
    : QObject(parent)
{
}

// ---- read access -----------------------------------------------------------

// One template helper instead of three copy-pasted loops. `auto&` works for
// both const and non-const vectors; returning a pointer lets us say "not
// found" as nullptr.
template <typename Vec>
static auto* findById(Vec& vec, const QString& id)
{
    for (auto& item : vec)
        if (item.id == id)
            return &item;
    using Item = std::remove_reference_t<decltype(vec[0])>;
    return static_cast<Item*>(nullptr);
}

const Category* AppData::categoryById(const QString& id) const { return findById(m_categories, id); }
const Activity* AppData::activityById(const QString& id) const { return findById(m_activities, id); }
const Event*    AppData::eventById(const QString& id)    const { return findById(m_events, id); }
Event*          AppData::mutableEventById(const QString& id)   { return findById(m_events, id); }

QVector<const Event*> AppData::eventsOn(QDate date) const
{
    QVector<const Event*> result;
    for (const Event& e : m_events)
        if (e.date == date)
            result.append(&e);

    // Sorted by start time so the UI can just draw them in order.
    std::sort(result.begin(), result.end(),
              [](const Event* a, const Event* b) {
                  return a->plannedStartMinutes < b->plannedStartMinutes;
              });
    return result;
}

int AppData::activityCountIn(const QString& categoryId) const
{
    int n = 0;
    for (const Activity& a : m_activities)
        if (a.categoryId == categoryId)
            ++n;
    return n;
}

int AppData::eventCountUsing(const QString& activityId) const
{
    int n = 0;
    for (const Event& e : m_events)
        if (e.activityId == activityId)
            ++n;
    return n;
}

bool AppData::isFree(QDate date, int startMin, int endMin,
                     const QString& ignoreEventId) const
{
    if (startMin < plan::kDayStartMinutes || endMin > plan::kDayEndMinutes
        || startMin >= endMin)
        return false;

    for (const Event& e : m_events) {
        if (e.date != date || e.id == ignoreEventId)
            continue;
        if (e.overlaps(startMin, endMin))
            return false;
    }
    return true;
}

// ---- mutations --------------------------------------------------------------

QString AppData::addCategory(const QString& name, const QColor& color)
{
    const QString trimmed = name.trimmed();
    if (trimmed.isEmpty())
        return {};

    Category c;
    c.id    = ids::newId();
    c.name  = trimmed;
    c.color = color.isValid() ? color : QColor("#4C6FE0");
    m_categories.append(c);

    emit changed();
    return c.id;
}

bool AppData::renameCategory(const QString& id, const QString& name)
{
    Category* c = findById(m_categories, id);
    if (!c || name.trimmed().isEmpty())
        return false;
    c->name = name.trimmed();
    emit changed();
    return true;
}

bool AppData::recolorCategory(const QString& id, const QColor& color)
{
    Category* c = findById(m_categories, id);
    if (!c || !color.isValid())
        return false;
    c->color = color;
    emit changed();
    return true;
}

bool AppData::removeCategory(const QString& id)
{
    // THE INTEGRITY RULE (Supplementary Spec): a category may only be
    // deleted once it contains no activities. Enforced here — the UI merely
    // hides the button, but even a buggy caller cannot break the data.
    if (activityCountIn(id) > 0)
        return false;

    const int before = m_categories.size();
    m_categories.erase(
        std::remove_if(m_categories.begin(), m_categories.end(),
                       [&](const Category& c) { return c.id == id; }),
        m_categories.end());

    if (m_categories.size() == before)
        return false;
    emit changed();
    return true;
}

QString AppData::addActivity(const QString& name, const QString& categoryId)
{
    // Referential integrity on CREATE too: an activity must point at a
    // category that actually exists, or the reference is born broken.
    if (name.trimmed().isEmpty() || !categoryById(categoryId))
        return {};

    Activity a;
    a.id         = ids::newId();
    a.name       = name.trimmed();
    a.categoryId = categoryId;
    m_activities.append(a);

    emit changed();
    return a.id;
}

bool AppData::removeActivity(const QString& id)
{
    // Twin integrity rule: an activity used by any planned block stays.
    if (eventCountUsing(id) > 0)
        return false;

    const int before = m_activities.size();
    m_activities.erase(
        std::remove_if(m_activities.begin(), m_activities.end(),
                       [&](const Activity& a) { return a.id == id; }),
        m_activities.end());

    if (m_activities.size() == before)
        return false;
    emit changed();
    return true;
}

QString AppData::addEvent(QDate date, int startMin, int endMin,
                          const QString& activityId)
{
    // UC1 extension 3a: "the chosen time is already occupied → System
    // declines and indicates the conflict." The decline happens here.
    if (!date.isValid() || !activityById(activityId)
        || !isFree(date, startMin, endMin))
        return {};

    Event e;
    e.id                  = ids::newId();
    e.date                = date;
    e.plannedStartMinutes = startMin;
    e.plannedEndMinutes   = endMin;
    e.activityId          = activityId;
    m_events.append(e);

    emit changed();
    return e.id;
}

bool AppData::moveEvent(const QString& id, int newStartMin)
{
    Event* e = mutableEventById(id);
    if (!e)
        return false;

    const int duration = e->plannedEndMinutes - e->plannedStartMinutes;
    if (!isFree(e->date, newStartMin, newStartMin + duration, /*ignore=*/id))
        return false;

    // UC1 extension *a: moving reschedules the PLAN only — the tracked
    // Segments travel with the Event untouched, because what really
    // happened is a fact and facts don't move.
    e->plannedStartMinutes = newStartMin;
    e->plannedEndMinutes   = newStartMin + duration;

    emit changed();
    return true;
}

bool AppData::setEventNote(const QString& id, const QString& note)
{
    Event* e = mutableEventById(id);
    if (!e)
        return false;
    e->note = note;
    emit changed();
    return true;
}

bool AppData::removeEvent(const QString& id)
{
    // Composition pays off: erasing the Event destroys its QVector<Segment>
    // with it. No manual cleanup, no leak possible. That's RAII.
    const int before = m_events.size();
    m_events.erase(
        std::remove_if(m_events.begin(), m_events.end(),
                       [&](const Event& e) { return e.id == id; }),
        m_events.end());

    if (m_events.size() == before)
        return false;

    // If the deleted event was the one being tracked, the crash-insurance
    // block would point at a ghost — clear it.
    if (m_running && m_running->eventId == id)
        m_running.reset();

    emit changed();
    return true;
}

bool AppData::appendSegment(const QString& eventId, const Segment& segment)
{
    Event* e = mutableEventById(eventId);
    if (!e || segment.seconds() <= 0)  // a zero-length segment is noise, drop it
        return false;
    e->segments.append(segment);
    emit changed();
    return true;
}

// ---- live-timer crash insurance ----------------------------------------------

void AppData::setRunning(const RunningState& state)
{
    m_running = state;
    emit changed(); // changed() -> save: the insurance MUST reach the disk
}

void AppData::touchRunning(const QDateTime& lastSeen)
{
    if (!m_running)
        return;
    m_running->lastSeen = lastSeen;
    emit changed();
}

void AppData::clearRunning()
{
    if (!m_running)
        return;
    m_running.reset();
    emit changed();
}

QString AppData::recoverInterruptedTracking()
{
    // Called once, right after load. If a RunningState is on disk, the app
    // previously died (crash, kill, power cut) while a timer ran: the clean
    // shutdown path always commits the segment and clears this block.
    if (!m_running)
        return {};

    const RunningState state = *m_running;
    m_running.reset();

    Segment s;
    s.kind  = state.kind;
    s.start = state.start;
    // We honestly do not know when the app died — the heartbeat's lastSeen
    // is our best evidence, so at most one heartbeat interval is lost.
    // (Supplementary Spec: "at most the current in-progress interval is
    // affected.")
    s.end   = state.lastSeen.isValid() ? state.lastSeen : state.start;

    const Event*    e = eventById(state.eventId);
    const Activity* a = e ? activityById(e->activityId) : nullptr;
    if (!e || s.seconds() <= 0)
        return {}; // nothing worth keeping — silently tidy up

    appendSegment(state.eventId, s);

    const QString name = a ? a->name : QStringLiteral("a block");
    return QStringLiteral("Recovered %1 min of tracked time on \"%2\" "
                          "from an interrupted session.")
        .arg(qMax<qint64>(1, s.seconds() / 60))
        .arg(name);
}

// ---- load & first run ----------------------------------------------------------

void AppData::resetFrom(QVector<Category> categories,
                        QVector<Activity> activities,
                        QVector<Event> events,
                        std::optional<RunningState> running)
{
    // Parameters taken BY VALUE + std::move: the caller builds the vectors,
    // we steal their contents instead of copying them. Move semantics
    // (C++11) — the reason modern C++ can pass big things around cheaply.
    m_categories = std::move(categories);
    m_activities = std::move(activities);
    m_events     = std::move(events);
    m_running    = std::move(running);
    // Deliberately no emit — see the header comment.
}

void AppData::seedDefaults()
{
    // The starter palette the prototype validated: five life areas that
    // together say "productivity has many dimensions" (design-doc §1) —
    // including the honest one nobody likes to log.
    const QString work   = addCategory("Work / Study",  QColor("#4C6FE0"));
    const QString social = addCategory("Social",        QColor("#E0688A"));
    const QString health = addCategory("Health",        QColor("#4CA96A"));
    const QString rest   = addCategory("Rest",          QColor("#8B6FD4"));
    const QString waste  = addCategory("Wasting time",  QColor("#C25B54"));

    addActivity("Study Math",     work);
    addActivity("Coding project", work);
    addActivity("Gym",            health);
    addActivity("Walk",           health);
    addActivity("Friends",        social);
    addActivity("Rest / nap",     rest);
    addActivity("Doomscroll",     waste);
}
