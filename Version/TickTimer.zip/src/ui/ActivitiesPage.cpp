#include "ActivitiesPage.h"

#include "Theme.h"
#include "Widgets.h"
#include "../domain/AppData.h"

#include <QColorDialog>
#include <QFrame>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QScrollArea>
#include <QVBoxLayout>

ActivitiesPage::ActivitiesPage(AppData* data, QWidget* parent)
    : QWidget(parent)
    , m_data(data)
{
    auto* layout = new QVBoxLayout(this);
    layout->setContentsMargins(26, 22, 26, 22);

    m_scroll = new QScrollArea(this);
    m_scroll->setWidgetResizable(true);
    layout->addWidget(m_scroll);

    connect(m_data, &AppData::changed, this, &ActivitiesPage::rebuild);
    rebuild();
}

void ActivitiesPage::rebuild()
{
    // takeWidget() hands the old content back to us WITH ownership —
    // deleting it deletes every child under it (Qt's parent-child tree
    // is a cascade delete). Then install the fresh one.
    delete m_scroll->takeWidget();
    m_scroll->setWidget(buildContent());
}

QWidget* ActivitiesPage::buildContent()
{
    auto* panel = new QFrame;
    panel->setObjectName("panel");
    panel->setMaximumWidth(640);

    auto* layout = new QVBoxLayout(panel);
    layout->setContentsMargins(18, 16, 18, 16);
    layout->setSpacing(10);

    auto* title = new QLabel(tr("Activities & categories"), panel);
    title->setObjectName("h2");
    auto* sub = new QLabel(
        tr("These feed your daily planner. Add a category, then add "
           "activities under it — changes appear instantly in the Calendar."),
        panel);
    sub->setObjectName("sub");
    sub->setWordWrap(true);
    layout->addWidget(title);
    layout->addWidget(sub);

    for (const Category& c : m_data->categories()) {
        auto* card = new QFrame(panel);
        card->setStyleSheet("QFrame { border:1px solid #E2E6E0; "
                            "border-radius:11px; background:white; }");
        auto* cardLayout = new QVBoxLayout(card);
        cardLayout->setContentsMargins(13, 11, 13, 11);
        cardLayout->setSpacing(6);

        // -- category header: dot, name, then Delete OR a count ------------
        auto* head = new QHBoxLayout;
        auto* dot = new QLabel(card);
        dot->setPixmap(colorDot(c.color, 11));
        dot->setStyleSheet("border:none;");
        auto* name = new QLabel(c.name, card);
        name->setStyleSheet("border:none; font-weight:700;");
        head->addWidget(dot);
        head->addWidget(name);
        head->addStretch(1);

        const int activityCount = m_data->activityCountIn(c.id);
        if (activityCount == 0) {
            auto* del = new QPushButton(tr("Delete"), card);
            del->setObjectName("danger");
            del->setCursor(Qt::PointingHandCursor);
            const QString categoryId = c.id; // captured by the lambda below
            connect(del, &QPushButton::clicked, this, [this, categoryId]() {
                m_data->removeCategory(categoryId);
            });
            head->addWidget(del);
        } else {
            auto* count = new QLabel(
                activityCount == 1 ? tr("1 activity")
                                   : tr("%1 activities").arg(activityCount),
                card);
            count->setStyleSheet("border:none; color:#616974; font-size:12px;");
            head->addWidget(count);
        }
        cardLayout->addLayout(head);

        // -- activity rows: dot, name, then ✕ OR "in use (n)" --------------
        for (const Activity& a : m_data->activities()) {
            if (a.categoryId != c.id)
                continue;
            auto* row = new QHBoxLayout;
            auto* aDot = new QLabel(card);
            aDot->setPixmap(colorDot(c.color, 9));
            aDot->setStyleSheet("border:none;");
            auto* aName = new QLabel(a.name, card);
            aName->setStyleSheet("border:none;");
            row->addWidget(aDot);
            row->addWidget(aName);
            row->addStretch(1);

            const int used = m_data->eventCountUsing(a.id);
            if (used > 0) {
                auto* tag = new QLabel(tr("in use (%1)").arg(used), card);
                tag->setStyleSheet(
                    "border:none; color:#616974; font-size:11px;");
                row->addWidget(tag);
            } else {
                auto* x = new QPushButton(QStringLiteral("\u00D7"), card);
                x->setObjectName("danger");
                x->setFixedWidth(24);
                x->setCursor(Qt::PointingHandCursor);
                const QString activityId = a.id;
                connect(x, &QPushButton::clicked, this, [this, activityId]() {
                    m_data->removeActivity(activityId);
                });
                row->addWidget(x);
            }
            cardLayout->addLayout(row);
        }

        // -- add-activity row ------------------------------------------------
        auto* addRow = new QHBoxLayout;
        auto* input = new QLineEdit(card);
        input->setPlaceholderText(tr("Add an activity…"));
        auto* addBtn = new QPushButton(tr("Add"), card);
        addBtn->setObjectName("primary");
        const QString categoryId = c.id;
        auto addActivity = [this, categoryId, input]() {
            // rebuild() will destroy `input`, so COPY the text out first —
            // a real lifetime lesson: never touch a widget after an action
            // that may tear the UI down.
            const QString name = input->text();
            m_data->addActivity(name, categoryId);
        };
        connect(addBtn, &QPushButton::clicked, this, addActivity);
        connect(input, &QLineEdit::returnPressed, this, addActivity);
        addRow->addWidget(input, 1);
        addRow->addWidget(addBtn);
        cardLayout->addLayout(addRow);

        layout->addWidget(card);
    }

    // -- add-category row ------------------------------------------------------
    auto* addCatRow = new QHBoxLayout;
    auto* catName = new QLineEdit(panel);
    catName->setPlaceholderText(tr("New category name"));
    auto* colorBtn = new QPushButton(panel);
    colorBtn->setFixedSize(38, 34);
    colorBtn->setCursor(Qt::PointingHandCursor);
    colorBtn->setStyleSheet(
        QStringLiteral("background:%1; border:1px solid #E2E6E0; "
                       "border-radius:9px;")
            .arg(m_newCategoryColor.name()));
    connect(colorBtn, &QPushButton::clicked, this, [this, colorBtn]() {
        const QColor picked =
            QColorDialog::getColor(m_newCategoryColor, this,
                                   tr("Category colour"));
        if (picked.isValid()) {
            m_newCategoryColor = picked; // survives rebuilds: lives on the page
            colorBtn->setStyleSheet(
                QStringLiteral("background:%1; border:1px solid #E2E6E0; "
                               "border-radius:9px;")
                    .arg(picked.name()));
        }
    });
    auto* addCatBtn = new QPushButton(tr("Add category"), panel);
    addCatBtn->setObjectName("primary");
    auto addCategory = [this, catName]() {
        m_data->addCategory(catName->text(), m_newCategoryColor);
    };
    connect(addCatBtn, &QPushButton::clicked, this, addCategory);
    connect(catName, &QLineEdit::returnPressed, this, addCategory);
    addCatRow->addWidget(catName, 1);
    addCatRow->addWidget(colorBtn);
    addCatRow->addWidget(addCatBtn);
    layout->addLayout(addCatRow);
    layout->addStretch(1);

    // Wrap in a plain host so the panel keeps its max width, centred-left.
    auto* host = new QWidget;
    auto* hostLayout = new QHBoxLayout(host);
    hostLayout->setContentsMargins(0, 0, 0, 0);
    hostLayout->addWidget(panel, 0, Qt::AlignTop);
    hostLayout->addStretch(1);
    return host;
}
