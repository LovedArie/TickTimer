#include "GlancePanel.h"

#include "Theme.h"
#include "Widgets.h"
#include "../domain/AppData.h"
#include "../domain/Stats.h"
#include "../tracking/TrackerService.h"

#include <QHBoxLayout>
#include <QLabel>
#include <QPainter>
#include <QVBoxLayout>

GlancePanel::GlancePanel(const AppData* data, const TrackerService* tracker,
                         QWidget* parent)
    : QFrame(parent)
    , m_data(data)
    , m_tracker(tracker)
    , m_date(QDate::currentDate())
{
    setObjectName("panel");

    auto* layout = new QVBoxLayout(this);
    layout->setContentsMargins(16, 14, 16, 16);
    layout->setSpacing(10);

    auto* title = new QLabel(tr("At a glance"), this);
    title->setObjectName("h2");
    auto* sub = new QLabel(
        tr("Calculated live from what you tracked — nothing is stored twice."),
        this);
    sub->setObjectName("sub");
    sub->setWordWrap(true);

    m_focusBox = new StatBox(tr("Focused"), theme::focus(), this);
    m_breakBox = new StatBox(tr("Break"), theme::brk(), this);
    auto* statRow = new QHBoxLayout;
    statRow->addWidget(m_focusBox);
    statRow->addWidget(m_breakBox);

    m_bars = new CategoryBars(this);

    m_encourage = new QLabel(this);
    m_encourage->setObjectName("encourage");
    m_encourage->setWordWrap(true);

    layout->addWidget(title);
    layout->addWidget(sub);
    layout->addLayout(statRow);
    layout->addWidget(m_bars);
    layout->addWidget(m_encourage);
    layout->addStretch(1);

    refresh();
}

void GlancePanel::setDate(QDate date)
{
    m_date = date;
    refresh();
}

void GlancePanel::refresh()
{
    // Step 1: derive today's numbers from raw Segments — nothing cached.
    stats::PeriodSummary s = stats::summarizeDay(*m_data, m_date);

    // Step 2: add the live, still-uncommitted interval so the numbers grow
    // before your eyes while you focus (motivation is a feature).
    if (m_tracker->state() != TrackerService::State::Idle) {
        const Event* e = m_data->eventById(m_tracker->trackedEventId());
        if (e && e->date == m_date) {
            const qint64 live = m_tracker->liveSeconds();
            if (m_tracker->state() == TrackerService::State::Focusing)
                s.totals.focusSeconds += live;
            else
                s.totals.breakSeconds += live;
            if (const Activity* a = m_data->activityById(e->activityId))
                s.byCategory[a->categoryId] += live;
        }
    }

    m_focusBox->setValue(stats::formatSeconds(s.totals.focusSeconds));
    m_breakBox->setValue(stats::formatSeconds(s.totals.breakSeconds));

    QVector<CategoryBars::Row> rows;
    for (const Category& c : m_data->categories())
        rows.append({c.name, c.color, s.byCategory.value(c.id, 0)});
    m_bars->setRows(std::move(rows));

    // The calm, non-shaming line (Supplementary Spec, Usability). Note what
    // it never says: "unproductive", "wasted", "only". Words are part of
    // the requirements here, not decoration.
    const qint64 total = s.totals.total();
    QString msg;
    if (total == 0) {
        msg = tr("A blank day is a fresh start. Plan a block and press "
                 "focus when you begin.");
    } else if (s.totals.focusSeconds * 100 >= total * 60) {
        msg = tr("Nice — most of your tracked time today was focused. "
                 "Keep the momentum.");
    } else {
        msg = tr("You've tracked %1 so far. Small steps count — pick one "
                 "thing and start the focus timer.")
                  .arg(stats::formatSeconds(total));
    }
    m_encourage->setText(msg);
}

// ---- CategoryBars -----------------------------------------------------------

namespace
{
constexpr int kRowHeight  = 34;
constexpr int kBarHeight  = 8;
} // namespace

CategoryBars::CategoryBars(QWidget* parent)
    : QWidget(parent)
{
}

void CategoryBars::setRows(QVector<Row> rows)
{
    m_rows = std::move(rows);
    updateGeometry(); // row count changed => our sizeHint changed
    update();
}

QSize CategoryBars::sizeHint() const
{
    return {260, m_rows.size() * kRowHeight};
}

void CategoryBars::paintEvent(QPaintEvent*)
{
    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing);

    p.setFont(scaledFont(font(), -1));

    // Bars are scaled to the LARGEST category, not to the day total — so
    // the biggest bar is always full width and the others read relative to
    // it, which is what the eye compares anyway (same as the prototype).
    qint64 maxSeconds = 1;
    for (const Row& r : m_rows)
        maxSeconds = qMax(maxSeconds, r.seconds);

    int y = 0;
    for (const Row& r : m_rows) {
        p.setBrush(r.color);
        p.setPen(Qt::NoPen);
        p.drawEllipse(QRect(0, y + 3, 9, 9));

        p.setPen(theme::ink());
        p.drawText(QRect(16, y, width() - 80, 16),
                   Qt::AlignLeft | Qt::AlignVCenter, r.name);
        p.setPen(theme::inkSoft());
        p.drawText(QRect(width() - 76, y, 76, 16),
                   Qt::AlignRight | Qt::AlignVCenter,
                   stats::formatSeconds(r.seconds));

        const QRect track(0, y + 19, width(), kBarHeight);
        p.setPen(Qt::NoPen);
        p.setBrush(theme::track());
        p.drawRoundedRect(track, 4, 4);
        if (r.seconds > 0) {
            const int w = int(qint64(track.width()) * r.seconds / maxSeconds);
            p.setBrush(r.color);
            p.drawRoundedRect(QRect(track.left(), track.top(),
                                    qMax(w, kBarHeight), kBarHeight), 4, 4);
        }
        y += kRowHeight;
    }
}
