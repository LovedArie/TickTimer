#include "AgendaWidget.h"

#include "Theme.h"
#include "Widgets.h"
#include "../domain/AppData.h"
#include "../domain/Stats.h"
#include "../tracking/TrackerService.h"

#include <QMouseEvent>
#include <QPainter>

namespace
{
// Geometry constants for THIS widget only — anonymous namespace keeps them
// invisible to every other file (the C++ way to say "file-private").
constexpr int kSlotHeight = 30; // pixels per 30-minute slot
constexpr int kGutter     = 64; // left column for "6 AM" labels
constexpr int kRadius     = 8;  // rounded corners

int slotTop(int slotIndex) { return slotIndex * kSlotHeight; }
} // namespace

AgendaWidget::AgendaWidget(const AppData* data, const TrackerService* tracker,
                           QWidget* parent)
    : QWidget(parent)
    , m_data(data)
    , m_tracker(tracker)
    , m_date(QDate::currentDate())
{
    // Without this, mouseMoveEvent only fires while a button is held.
    // We want hover feedback ("+ plan"), so track all movement.
    setMouseTracking(true);
    setMinimumHeight(sizeHint().height());
}

void AgendaWidget::setDate(QDate date)
{
    if (m_date == date)
        return;
    m_date = date;
    update(); // schedule a repaint — NEVER paint directly from here
}

QSize AgendaWidget::sizeHint() const
{
    return {560, plan::kSlotsPerDay * kSlotHeight + 12};
}

QRect AgendaWidget::eventRect(const Event& e) const
{
    // Minutes -> pixels: the single place this conversion exists, so
    // painting and clicking can never disagree about where things are.
    const int startSlot =
        (e.plannedStartMinutes - plan::kDayStartMinutes) / plan::kSlotMinutes;
    const int slotCount =
        (e.plannedEndMinutes - e.plannedStartMinutes) / plan::kSlotMinutes;
    return QRect(kGutter, slotTop(startSlot) + 2,
                 width() - kGutter - 4, slotCount * kSlotHeight - 4);
}

int AgendaWidget::slotAt(const QPoint& pos) const
{
    if (pos.x() < kGutter)
        return -1;
    const int slot = pos.y() / kSlotHeight;
    return (slot >= 0 && slot < plan::kSlotsPerDay) ? slot : -1;
}

void AgendaWidget::paintEvent(QPaintEvent*)
{
    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing);

    const QFont small = scaledFont(font(), -1.5);

    // 1) The time grid: solid line + label on the hour, dashed on the half.
    for (int i = 0; i < plan::kSlotsPerDay; ++i) {
        const int y = slotTop(i);
        const bool onTheHour = (i % 2 == 0);

        p.setPen(QPen(onTheHour ? theme::line() : QColor("#EEF0EC"), 1,
                      onTheHour ? Qt::SolidLine : Qt::DashLine));
        p.drawLine(kGutter, y, width(), y);

        if (onTheHour) {
            p.setPen(theme::inkSoft());
            p.setFont(small);
            const int minutes = plan::kDayStartMinutes + i * plan::kSlotMinutes;
            p.drawText(QRect(0, y - 8, kGutter - 10, 16),
                       Qt::AlignRight | Qt::AlignVCenter,
                       timeLabel(minutes).remove(":00")); // "6 AM", not "6:00 AM"
        }
    }

    // 2) Hover hint on a free slot — the invitation to plan.
    if (m_hoverSlot >= 0) {
        const QRect r(kGutter, slotTop(m_hoverSlot) + 2,
                      width() - kGutter - 4, kSlotHeight - 4);
        p.setPen(Qt::NoPen);
        p.setBrush(QColor(47, 126, 110, 18));
        p.drawRoundedRect(r, kRadius, kRadius);
        p.setPen(theme::focus());
        p.setFont(small);
        p.drawText(r.adjusted(12, 0, 0, 0), Qt::AlignLeft | Qt::AlignVCenter,
                   QStringLiteral("+ plan"));
    }

    // 3) The planned Events, each in its category's colour, with the little
    //    plan-vs-actual bar along the bottom — reality visibly filling the
    //    plan, which is the entire idea of the app in one pixel strip.
    for (const Event* e : m_data->eventsOn(m_date)) {
        const Activity* activity = m_data->activityById(e->activityId);
        const Category* category =
            activity ? m_data->categoryById(activity->categoryId) : nullptr;
        const QColor color = category ? category->color : theme::inkSoft();
        const QRect  rect  = eventRect(*e);

        p.setPen(Qt::NoPen);
        p.setBrush(color);
        p.drawRoundedRect(rect, kRadius + 1, kRadius + 1);

        // Committed totals + the live, still-running seconds if this very
        // block is being tracked right now.
        stats::Totals t = stats::eventTotals(*e);
        if (m_tracker->isTrackingEvent(e->id)) {
            if (m_tracker->state() == TrackerService::State::Focusing)
                t.focusSeconds += m_tracker->liveSeconds();
            else
                t.breakSeconds += m_tracker->liveSeconds();
        }

        const QRect inner = rect.adjusted(11, 5, -8, -5);
        p.setPen(Qt::white);
        QFont bold = font();
        bold.setBold(true);
        p.setFont(bold);
        p.drawText(inner, Qt::AlignLeft | Qt::AlignTop,
                   activity ? activity->name : QStringLiteral("(missing)"));

        if (rect.height() >= 2 * kSlotHeight - 6) { // room for a second line
            p.setFont(small);
            p.setPen(QColor(255, 255, 255, 220));
            const int slotCount = (e->plannedEndMinutes - e->plannedStartMinutes)
                              / plan::kSlotMinutes;
            p.drawText(inner.adjusted(0, 18, 0, 0), Qt::AlignLeft | Qt::AlignTop,
                       QStringLiteral("%1 – %2 · %3")
                           .arg(timeLabel(e->plannedStartMinutes),
                                timeLabel(e->plannedEndMinutes),
                                durationLabel(slotCount)));
        }

        // Mini plan-vs-actual bar.
        const QRect bar(inner.left(), rect.bottom() - 9, inner.width(), 5);
        p.setPen(Qt::NoPen);
        p.setBrush(QColor(255, 255, 255, 80));
        p.drawRoundedRect(bar, 2, 2);

        const qint64 planned = e->plannedSeconds();
        if (planned > 0 && t.total() > 0) {
            const int fw = int(bar.width() * qMin<qint64>(t.focusSeconds, planned) / planned);
            const int bw = int(bar.width() * qMin<qint64>(t.breakSeconds, planned - qMin(t.focusSeconds, planned)) / planned);
            p.setBrush(QColor(255, 255, 255, 240));
            p.drawRoundedRect(QRect(bar.left(), bar.top(), fw, bar.height()), 2, 2);
            p.setBrush(QColor(255, 255, 255, 140));
            p.drawRoundedRect(QRect(bar.left() + fw, bar.top(), bw, bar.height()), 2, 2);
        }
    }
}

void AgendaWidget::mousePressEvent(QMouseEvent* event)
{
    // Events first — they sit on top of slots, so they win the click,
    // exactly as they win visually.
    for (const Event* e : m_data->eventsOn(m_date)) {
        if (eventRect(*e).contains(event->pos())) {
            emit eventClicked(e->id);
            return;
        }
    }

    const int slot = slotAt(event->pos());
    if (slot < 0)
        return;
    const int startMin = plan::kDayStartMinutes + slot * plan::kSlotMinutes;
    if (m_data->isFree(m_date, startMin, startMin + plan::kSlotMinutes))
        emit emptySlotClicked(slot);
}

void AgendaWidget::mouseMoveEvent(QMouseEvent* event)
{
    bool overEvent = false;
    for (const Event* e : m_data->eventsOn(m_date))
        if (eventRect(*e).contains(event->pos()))
            overEvent = true;

    int hover = slotAt(event->pos());
    if (hover >= 0 && !overEvent) {
        const int startMin = plan::kDayStartMinutes + hover * plan::kSlotMinutes;
        if (!m_data->isFree(m_date, startMin, startMin + plan::kSlotMinutes))
            hover = -1; // occupied — no "+ plan" invitation
    } else {
        hover = -1;
    }

    setCursor(overEvent || hover >= 0 ? Qt::PointingHandCursor
                                      : Qt::ArrowCursor);
    if (hover != m_hoverSlot) {
        m_hoverSlot = hover;
        update();
    }
}

void AgendaWidget::leaveEvent(QEvent*)
{
    if (m_hoverSlot != -1) {
        m_hoverSlot = -1;
        update();
    }
}
