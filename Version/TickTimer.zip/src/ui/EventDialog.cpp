#include "EventDialog.h"

#include "Theme.h"
#include "Widgets.h"
#include "../domain/AppData.h"
#include "../domain/Stats.h"
#include "../tracking/TrackerService.h"

#include <QHBoxLayout>
#include <QLabel>
#include <QPainter>
#include <QPlainTextEdit>
#include <QPushButton>
#include <QStyle>
#include <QVBoxLayout>

EventDialog::EventDialog(AppData* data, TrackerService* tracker,
                         const QString& eventId, QWidget* parent)
    : QDialog(parent)
    , m_data(data)
    , m_tracker(tracker)
    , m_eventId(eventId)
{
    setWindowTitle(tr("Planned block"));
    setMinimumWidth(420);

    auto* layout = new QVBoxLayout(this);
    layout->setContentsMargins(20, 18, 20, 16);
    layout->setSpacing(10);

    // Header: colour swatch + activity name.
    m_swatch = new QLabel(this);
    m_swatch->setFixedSize(15, 15);
    m_title = new QLabel(this);
    m_title->setObjectName("h2");
    auto* headRow = new QHBoxLayout;
    headRow->setSpacing(9);
    headRow->addWidget(m_swatch);
    headRow->addWidget(m_title, 1);

    m_plannedLine = new QLabel(this);
    m_plannedLine->setObjectName("sub");

    // Reschedule row — the four nudge buttons from the prototype. Each is
    // wired to the same slot with a different delta; the domain's isFree()
    // decides (via refresh) which are enabled.
    auto* moveRow = new QHBoxLayout;
    moveRow->setSpacing(6);
    auto* moveCaption = new QLabel(tr("Reschedule"), this);
    moveCaption->setObjectName("sub");
    const struct { const char* text; int delta; } moves[] = {
        {"\u25B2 1h", -2}, {"\u25B2 30m", -1},
        {"30m \u25BC", +1}, {"1h \u25BC", +2},
    };
    for (const auto& m : moves) {
        auto* b = new QPushButton(QString::fromUtf8(m.text), this);
        const int delta = m.delta;
        connect(b, &QPushButton::clicked, this,
                [this, delta]() { moveBySlots(delta); });
        m_moveButtons.append(b);
        moveRow->addWidget(b);
    }

    m_pva = new PvaBar(this);
    m_legend = new QLabel(this);
    m_legend->setObjectName("sub");

    m_stateLabel = new QLabel(this);

    m_focusBtn = new QPushButton(tr("Start focus"), this);
    m_focusBtn->setObjectName("primary");
    m_breakBtn = new QPushButton(tr("Take a break"), this);
    m_breakBtn->setObjectName("breakBtn");
    m_stopBtn = new QPushButton(tr("Stop"), this);
    m_stopBtn->setObjectName("quiet");
    auto* btnRow = new QHBoxLayout;
    btnRow->addWidget(m_focusBtn);
    btnRow->addWidget(m_breakBtn);
    btnRow->addWidget(m_stopBtn);

    m_note = new QPlainTextEdit(this);
    m_note->setPlaceholderText(
        tr("A quick note… (how did it go? did anxiety creep in?)"));
    m_note->setFixedHeight(64);

    auto* deleteBtn = new QPushButton(tr("Delete this block"), this);
    deleteBtn->setObjectName("danger");
    deleteBtn->setCursor(Qt::PointingHandCursor);

    layout->addLayout(headRow);
    layout->addWidget(m_plannedLine);
    layout->addWidget(moveCaption);
    layout->addLayout(moveRow);
    layout->addWidget(m_pva);
    layout->addWidget(m_legend);
    layout->addWidget(m_stateLabel);
    layout->addLayout(btnRow);
    layout->addWidget(m_note);
    layout->addWidget(deleteBtn, 0, Qt::AlignLeft);

    // Wiring. Note the shape of every connection: UI event -> service call.
    // The dialog never edits its own labels in these slots — it lets the
    // services change reality, hears about it, and re-reads it in refresh().
    connect(m_focusBtn, &QPushButton::clicked, this,
            [this]() { m_tracker->startFocus(m_eventId); });
    connect(m_breakBtn, &QPushButton::clicked, this,
            [this]() { m_tracker->startBreak(m_eventId); });
    connect(m_stopBtn, &QPushButton::clicked,
            m_tracker, &TrackerService::stop);
    connect(m_note, &QPlainTextEdit::textChanged,
            this, &EventDialog::saveNote);
    connect(deleteBtn, &QPushButton::clicked,
            this, &EventDialog::deleteEvent);

    connect(m_tracker, &TrackerService::stateChanged,
            this, &EventDialog::refresh);
    connect(m_tracker, &TrackerService::tick,
            this, &EventDialog::refresh); // live numbers every second
    connect(m_data, &AppData::changed,
            this, &EventDialog::refresh);

    // Seed the note ONCE — refresh() never touches it again, or every
    // keystroke would trigger changed() -> refresh() -> setPlainText() and
    // fight the user for the cursor. Feedback loops are THE classic
    // signals-and-slots trap; the m_updatingUi guard is the standard cure.
    if (const Event* e = m_data->eventById(m_eventId)) {
        m_updatingUi = true;
        m_note->setPlainText(e->note);
        m_updatingUi = false;
    }

    refresh();
}

void EventDialog::refresh()
{
    const Event* e = m_data->eventById(m_eventId);
    if (!e) {         // deleted while we were open (or vanished on load)
        reject();
        return;
    }

    const Activity* a = m_data->activityById(e->activityId);
    const Category* c = a ? m_data->categoryById(a->categoryId) : nullptr;
    const QColor color = c ? c->color : theme::inkSoft();

    m_swatch->setStyleSheet(
        QStringLiteral("background:%1; border-radius:5px;").arg(color.name()));
    m_title->setText(a ? a->name : tr("(missing activity)"));

    const int slotCount = (e->plannedEndMinutes - e->plannedStartMinutes)
                      / plan::kSlotMinutes;
    m_plannedLine->setText(QStringLiteral("%1 · planned %2 – %3 (%4)")
                               .arg(c ? c->name : QString(),
                                    timeLabel(e->plannedStartMinutes),
                                    timeLabel(e->plannedEndMinutes),
                                    durationLabel(slotCount)));

    // Enable each nudge only if the landing spot is free — the UI makes
    // illegal moves unreachable; the domain makes them impossible.
    const int deltas[] = {-2, -1, +1, +2};
    for (int i = 0; i < m_moveButtons.size(); ++i) {
        const int newStart =
            e->plannedStartMinutes + deltas[i] * plan::kSlotMinutes;
        m_moveButtons[i]->setEnabled(m_data->isFree(
            e->date, newStart,
            newStart + slotCount * plan::kSlotMinutes, e->id));
    }

    stats::Totals t = stats::eventTotals(*e);
    const bool trackingThis = m_tracker->isTrackingEvent(m_eventId);
    if (trackingThis) {
        if (m_tracker->state() == TrackerService::State::Focusing)
            t.focusSeconds += m_tracker->liveSeconds();
        else
            t.breakSeconds += m_tracker->liveSeconds();
    }

    m_pva->setValues(t.focusSeconds, t.breakSeconds, e->plannedSeconds());
    m_legend->setText(QStringLiteral("%1 focused · %2 on break · %3 untracked")
                          .arg(stats::formatSeconds(t.focusSeconds),
                               stats::formatSeconds(t.breakSeconds),
                               stats::formatSeconds(qMax<qint64>(
                                   0, e->plannedSeconds() - t.total()))));

    if (!trackingThis) {
        m_stateLabel->setObjectName("stateIdle");
        m_stateLabel->setText(tr("Idle — not tracking"));
    } else if (m_tracker->state() == TrackerService::State::Focusing) {
        m_stateLabel->setObjectName("stateFocusing");
        m_stateLabel->setText(tr("● Focusing"));
    } else {
        m_stateLabel->setObjectName("stateOnBreak");
        m_stateLabel->setText(tr("● On a break"));
    }
    // Changing objectName after the fact needs a style nudge:
    m_stateLabel->style()->unpolish(m_stateLabel);
    m_stateLabel->style()->polish(m_stateLabel);

    m_focusBtn->setEnabled(!(trackingThis
        && m_tracker->state() == TrackerService::State::Focusing));
    m_breakBtn->setEnabled(!(trackingThis
        && m_tracker->state() == TrackerService::State::OnBreak));
    m_stopBtn->setEnabled(trackingThis);
}

void EventDialog::moveBySlots(int deltaSlots)
{
    const Event* e = m_data->eventById(m_eventId);
    if (!e)
        return;
    m_data->moveEvent(m_eventId, e->plannedStartMinutes
                                     + deltaSlots * plan::kSlotMinutes);
    // No manual UI update: moveEvent emits changed(), changed() calls
    // refresh(). One path for updates, always.
}

void EventDialog::saveNote()
{
    if (m_updatingUi)
        return;
    m_updatingUi = true; // our own setEventNote fires changed()->refresh()
    m_data->setEventNote(m_eventId, m_note->toPlainText());
    m_updatingUi = false;
}

void EventDialog::deleteEvent()
{
    // Order matters: stop (and commit) the live interval BEFORE the event
    // disappears, or the segment would have nowhere to land.
    if (m_tracker->isTrackingEvent(m_eventId))
        m_tracker->stop();
    m_data->removeEvent(m_eventId);
    // refresh() sees the event is gone and reject()s the dialog.
}

// ---- PvaBar ------------------------------------------------------------------

PvaBar::PvaBar(QWidget* parent)
    : QWidget(parent)
{
    setFixedHeight(20);
}

void PvaBar::setValues(qint64 focusSecs, qint64 breakSecs, qint64 plannedSecs)
{
    m_focus   = focusSecs;
    m_break   = breakSecs;
    m_planned = qMax<qint64>(1, plannedSecs);
    update();
}

void PvaBar::paintEvent(QPaintEvent*)
{
    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing);
    p.setPen(Qt::NoPen);

    p.setBrush(theme::track());
    p.drawRoundedRect(rect(), 7, 7);

    const int fw = int(qint64(width()) * qMin(m_focus, m_planned) / m_planned);
    const qint64 breakRoom = m_planned - qMin(m_focus, m_planned);
    const int bw = int(qint64(width()) * qMin(m_break, breakRoom) / m_planned);

    if (fw > 0) {
        p.setBrush(theme::focus());
        p.drawRoundedRect(QRect(0, 0, fw, height()), 7, 7);
    }
    if (bw > 0) {
        p.setBrush(theme::brk());
        p.drawRect(QRect(fw, 0, bw, height()));
    }
}
