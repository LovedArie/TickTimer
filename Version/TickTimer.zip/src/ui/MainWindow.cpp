#include "MainWindow.h"

#include "ActivitiesPage.h"
#include "PlannerPage.h"
#include "PomodoroPage.h"
#include "Theme.h"

#include <QCloseEvent>
#include <QHBoxLayout>
#include <QLabel>
#include <QStackedWidget>
#include <QStatusBar>
#include <QToolButton>
#include <QVBoxLayout>

MainWindow::MainWindow()
    : m_store(JsonStore::defaultFilePath())
    , m_tracker(&m_data)
{
    setWindowTitle(tr("Time & Focus Tracker"));
    resize(1150, 780);

    // ---- THE autosave line (wired FIRST, before any data exists) ----------
    // Every changed() — one keystroke in a note, one committed segment,
    // one heartbeat — flows through here to the disk. QSaveFile makes each
    // write atomic, so there is never a moment when the file is half-written.
    // Order matters: connect BEFORE loading/seeding, so even the first-run
    // seed categories are saved the instant they're created. (Loading
    // itself doesn't re-trigger a save — resetFrom deliberately stays
    // silent, exactly for this wiring.)
    connect(&m_data, &AppData::changed, this, [this]() {
        if (!m_store.save(m_data))
            statusBar()->showMessage(
                tr("Save failed: %1").arg(m_store.errorMessage()));
    });

    // ---- STARTUP SEQUENCE (order is the design) ---------------------------
    // 1. Load everything from disk (design-doc §4: load-all on startup).
    // 2. If a RunningState survived — the app died while tracking — turn
    //    it into a real Segment and tell the user what was rescued.
    // 3. First run (no file): seed the starter categories instead.
    QString recoveryMessage;
    if (m_store.load(m_data))
        recoveryMessage = m_data.recoverInterruptedTracking();
    else
        m_data.seedDefaults();

    // ---- chrome: header, left nav, page stack ------------------------------
    auto* central = new QWidget(this);
    auto* rootLayout = new QVBoxLayout(central);
    rootLayout->setContentsMargins(0, 0, 0, 0);
    rootLayout->setSpacing(0);

    auto* header = new QWidget(central);
    header->setStyleSheet(
        "background: white; border-bottom: 1px solid #E2E6E0;");
    auto* headerLayout = new QHBoxLayout(header);
    headerLayout->setContentsMargins(24, 14, 24, 14);
    auto* brand = new QLabel(tr("Time & Focus Tracker"), header);
    brand->setObjectName("h1");
    brand->setStyleSheet("border: none;");
    auto* tag = new QLabel(tr("plan vs. actual — see where your time goes"),
                           header);
    tag->setObjectName("sub");
    tag->setStyleSheet("border: none; color:#616974;");
    headerLayout->addWidget(brand);
    headerLayout->addSpacing(10);
    headerLayout->addWidget(tag);
    headerLayout->addStretch(1);

    auto* body = new QWidget(central);
    auto* bodyLayout = new QHBoxLayout(body);
    bodyLayout->setContentsMargins(0, 0, 0, 0);
    bodyLayout->setSpacing(0);

    auto* nav = new QWidget(body);
    nav->setFixedWidth(190);
    nav->setStyleSheet("border-right: 1px solid #E2E6E0;");
    auto* navLayout = new QVBoxLayout(nav);
    navLayout->setContentsMargins(12, 18, 12, 18);
    navLayout->setSpacing(4);

    m_pages = new QStackedWidget(body);
    m_pages->addWidget(new PlannerPage(&m_data, &m_tracker, m_pages));
    m_pages->addWidget(new ActivitiesPage(&m_data, m_pages));
    m_pages->addWidget(new PomodoroPage(m_pages));

    const char* navNames[] = {"Calendar", "Activities", "Pomodoro"};
    for (int i = 0; i < 3; ++i) {
        auto* b = new QToolButton(nav);
        b->setObjectName("nav");
        b->setText(tr(navNames[i]));
        b->setCheckable(true);
        b->setChecked(i == 0);
        b->setAutoExclusive(true); // radio behaviour among siblings
        b->setCursor(Qt::PointingHandCursor);
        b->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
        connect(b, &QToolButton::clicked, this,
                [this, i]() { m_pages->setCurrentIndex(i); });
        navLayout->addWidget(b);
    }
    navLayout->addStretch(1);

    bodyLayout->addWidget(nav);
    bodyLayout->addWidget(m_pages, 1);

    rootLayout->addWidget(header);
    rootLayout->addWidget(body, 1);
    setCentralWidget(central);

    statusBar()->showMessage(
        !recoveryMessage.isEmpty()
            ? recoveryMessage
            : tr("Data file: %1").arg(m_store.filePath()),
        /*ms=*/8000);
}

void MainWindow::closeEvent(QCloseEvent* event)
{
    // Clean shutdown: stop() commits any live interval as a Segment and
    // clears the crash insurance — both of which emit changed() and hence
    // already saved. The explicit save after is belt-and-braces (it also
    // covers the nothing-was-running case where stop() is a no-op).
    m_tracker.stop();
    m_store.save(m_data);
    event->accept();
}
