#include "PlannerPage.h"

#include "AgendaWidget.h"
#include "EventDialog.h"
#include "GlancePanel.h"
#include "PickActivityDialog.h"
#include "ReviewWidgets.h"
#include "../domain/AppData.h"
#include "../domain/Event.h"
#include "../tracking/TrackerService.h"

#include <QButtonGroup>
#include <QFrame>
#include <QHBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QScrollArea>
#include <QStackedWidget>
#include <QVBoxLayout>

PlannerPage::PlannerPage(AppData* data, TrackerService* tracker,
                         QWidget* parent)
    : QWidget(parent)
    , m_data(data)
    , m_tracker(tracker)
    , m_date(QDate::currentDate())
{
    auto* layout = new QVBoxLayout(this);
    layout->setContentsMargins(26, 16, 26, 20);
    layout->setSpacing(12);

    // ---- top bar: ‹ Today ›            [Day | Week | Month] --------------
    auto* topBar = new QHBoxLayout;

    auto* prev = new QPushButton(QStringLiteral("\u2039"), this);
    auto* next = new QPushButton(QStringLiteral("\u203A"), this);
    prev->setFixedWidth(34);
    next->setFixedWidth(34);
    connect(prev, &QPushButton::clicked, this, [this]() { shiftPeriod(-1); });
    connect(next, &QPushButton::clicked, this, [this]() { shiftPeriod(+1); });

    m_periodLabel = new QLabel(this);
    m_periodLabel->setObjectName("h2");
    m_periodLabel->setMinimumWidth(150);
    m_periodLabel->setAlignment(Qt::AlignCenter);

    topBar->addWidget(prev);
    topBar->addWidget(m_periodLabel);
    topBar->addWidget(next);
    topBar->addStretch(1);

    // The segmented Day/Week/Month control: three checkable buttons in an
    // EXCLUSIVE QButtonGroup — the group enforces radio-button behaviour
    // (exactly one checked) so we don't hand-manage check states.
    auto* group = new QButtonGroup(this);
    group->setExclusive(true);
    const char* labels[] = {"Day", "Week", "Month"};
    for (int i = 0; i < 3; ++i) {
        auto* b = new QPushButton(tr(labels[i]), this);
        b->setObjectName("segment");
        b->setCheckable(true);
        b->setChecked(i == 0);
        b->setCursor(Qt::PointingHandCursor);
        group->addButton(b, i); // the id doubles as our mode number
        m_modeButtons.append(b);
        topBar->addWidget(b);
    }
    connect(group, &QButtonGroup::idClicked, this, &PlannerPage::setMode);

    layout->addLayout(topBar);

    // ---- the three views, stacked; only one visible at a time ------------
    m_stack = new QStackedWidget(this);

    // Day view: the agenda panel on the left, the glance panel on the right.
    auto* dayView = new QWidget(this);
    auto* dayLayout = new QHBoxLayout(dayView);
    dayLayout->setContentsMargins(0, 0, 0, 0);
    dayLayout->setSpacing(18);

    auto* agendaPanel = new QFrame(dayView);
    agendaPanel->setObjectName("panel");
    auto* agendaLayout = new QVBoxLayout(agendaPanel);
    agendaLayout->setContentsMargins(16, 14, 16, 14);
    agendaLayout->setSpacing(6);
    auto* agendaTitle = new QLabel(tr("Your day"), agendaPanel);
    agendaTitle->setObjectName("h2");
    auto* agendaSub = new QLabel(
        tr("6 AM to midnight · 30-minute slots · click a free slot to say "
           "what you're doing"),
        agendaPanel);
    agendaSub->setObjectName("sub");

    m_agenda = new AgendaWidget(m_data, m_tracker, agendaPanel);
    auto* agendaScroll = new QScrollArea(agendaPanel);
    agendaScroll->setWidgetResizable(true);
    agendaScroll->setWidget(m_agenda);

    agendaLayout->addWidget(agendaTitle);
    agendaLayout->addWidget(agendaSub);
    agendaLayout->addWidget(agendaScroll, 1);

    m_glance = new GlancePanel(m_data, m_tracker, dayView);
    m_glance->setFixedWidth(320);

    dayLayout->addWidget(agendaPanel, 1);
    dayLayout->addWidget(m_glance);

    m_week  = new WeekReviewPage(m_data, this);
    m_month = new MonthReviewPage(m_data, this);

    m_stack->addWidget(dayView); // index 0 == mode 0, and so on
    m_stack->addWidget(m_week);
    m_stack->addWidget(m_month);
    layout->addWidget(m_stack, 1);

    // ---- wiring ------------------------------------------------------------
    connect(m_agenda, &AgendaWidget::emptySlotClicked,
            this, &PlannerPage::onEmptySlotClicked);
    connect(m_agenda, &AgendaWidget::eventClicked,
            this, &PlannerPage::onEventClicked);

    connect(m_data, &AppData::changed, this, &PlannerPage::refresh);

    // The 1-second tick repaints the live numbers. The agenda gets a plain
    // update() (repaint me); the glance re-derives its stats. Cheap enough
    // at once a second — measure before optimizing (and it only ticks
    // while a timer runs at all).
    connect(m_tracker, &TrackerService::tick, this, [this]() {
        m_agenda->update();
        m_glance->refresh();
    });
    connect(m_tracker, &TrackerService::stateChanged, this,
            &PlannerPage::refresh);

    updatePeriodLabel();
}

void PlannerPage::shiftPeriod(int direction)
{
    // ‹ and › move by whatever the current view shows — a day, a week, or
    // a month. One date field serves all three views; each interprets it.
    switch (m_mode) {
    case 0: m_date = m_date.addDays(direction);      break;
    case 1: m_date = m_date.addDays(7 * direction);  break;
    case 2: m_date = m_date.addMonths(direction);    break;
    }
    m_agenda->setDate(m_date);
    m_glance->setDate(m_date);
    m_week->setDate(m_date);
    m_month->setDate(m_date);
    updatePeriodLabel();
}

void PlannerPage::setMode(int mode)
{
    m_mode = mode;
    m_stack->setCurrentIndex(mode);
    updatePeriodLabel();
}

void PlannerPage::updatePeriodLabel()
{
    const QDate today = QDate::currentDate();
    QString text;
    switch (m_mode) {
    case 0:
        if (m_date == today)                 text = tr("Today");
        else if (m_date == today.addDays(-1)) text = tr("Yesterday");
        else if (m_date == today.addDays(1))  text = tr("Tomorrow");
        else                                  text = m_date.toString("ddd, MMM d");
        break;
    case 1: {
        const QDate monday = m_date.addDays(1 - m_date.dayOfWeek());
        text = tr("Week of %1").arg(monday.toString("MMM d"));
        break;
    }
    case 2:
        text = m_date.toString("MMMM yyyy");
        break;
    }
    m_periodLabel->setText(text);
}

void PlannerPage::onEmptySlotClicked(int slotIndex)
{
    // UC1, the whole main flow in four lines: ask (dialog), and if the
    // user confirmed, tell the domain. The dialog collected the answer;
    // AppData applies the rules; changed() repaints the world.
    PickActivityDialog dialog(m_data, m_date, slotIndex, this);
    if (dialog.exec() == QDialog::Accepted
        && !dialog.chosenActivityId().isEmpty()) {
        m_data->addEvent(m_date, dialog.chosenStartMinutes(),
                         dialog.chosenEndMinutes(),
                         dialog.chosenActivityId());
    }
}

void PlannerPage::onEventClicked(const QString& eventId)
{
    EventDialog dialog(m_data, m_tracker, eventId, this);
    dialog.exec();
    // Nothing to do afterwards: every change the dialog made already went
    // through AppData/TrackerService and reached us via changed().
}

void PlannerPage::refresh()
{
    m_agenda->update();
    m_glance->refresh();
    // Week/month pages listen to AppData::changed themselves.
}
