#include "PomodoroPage.h"

#include "Theme.h"
#include "Widgets.h"

#include <QHBoxLayout>
#include <QLabel>
#include <QPainter>
#include <QPushButton>
#include <QVBoxLayout>

namespace
{
constexpr int kFocusSeconds      = 25 * 60;
constexpr int kShortBreakSeconds = 5 * 60;
constexpr int kLongBreakSeconds  = 15 * 60;
constexpr int kRoundsPerCycle    = 4; // long break every 4th round
} // namespace

PomodoroPage::PomodoroPage(QWidget* parent)
    : QWidget(parent)
    , m_remaining(kFocusSeconds)
{
    auto* layout = new QVBoxLayout(this);
    layout->setContentsMargins(26, 40, 26, 26);
    layout->setSpacing(16);
    layout->setAlignment(Qt::AlignHCenter | Qt::AlignTop);

    m_phaseLabel = new QLabel(this);
    m_phaseLabel->setStyleSheet("font-size:17px; font-weight:800;");
    m_phaseLabel->setAlignment(Qt::AlignCenter);

    m_ring = new PomodoroRing(this);

    // The four round dots.
    auto* dotsRow = new QHBoxLayout;
    dotsRow->setSpacing(8);
    dotsRow->addStretch(1);
    for (int i = 0; i < kRoundsPerCycle; ++i) {
        auto* dot = new QLabel(this);
        dot->setFixedSize(11, 11);
        m_dots.append(dot);
        dotsRow->addWidget(dot);
    }
    dotsRow->addStretch(1);

    m_startBtn = new QPushButton(tr("Start"), this);
    m_startBtn->setObjectName("primary");
    auto* resetBtn = new QPushButton(tr("Reset"), this);
    resetBtn->setObjectName("quiet");
    auto* skipBtn = new QPushButton(tr("Skip"), this);
    skipBtn->setObjectName("quiet");
    auto* buttons = new QHBoxLayout;
    buttons->setSpacing(8);
    buttons->addStretch(1);
    buttons->addWidget(m_startBtn);
    buttons->addWidget(resetBtn);
    buttons->addWidget(skipBtn);
    buttons->addStretch(1);

    auto* hint = new QLabel(
        tr("25 min focus, 5 min break, a longer break every 4th round. "
           "Skip to preview the next phase."),
        this);
    hint->setObjectName("sub");
    hint->setAlignment(Qt::AlignCenter);
    hint->setWordWrap(true);
    hint->setMaximumWidth(300);

    layout->addWidget(m_phaseLabel);
    layout->addWidget(m_ring, 0, Qt::AlignHCenter);
    layout->addLayout(dotsRow);
    layout->addLayout(buttons);
    layout->addWidget(hint, 0, Qt::AlignHCenter);
    layout->addStretch(1);

    m_timer.setInterval(1000);
    connect(&m_timer, &QTimer::timeout, this, &PomodoroPage::tick);
    connect(m_startBtn, &QPushButton::clicked,
            this, &PomodoroPage::toggleRunning);
    connect(resetBtn, &QPushButton::clicked, this, &PomodoroPage::reset);
    connect(skipBtn, &QPushButton::clicked, this, &PomodoroPage::skip);

    refresh();
}

int PomodoroPage::phaseTotalSeconds() const
{
    switch (m_phase) {
    case Phase::Focus:      return kFocusSeconds;
    case Phase::ShortBreak: return kShortBreakSeconds;
    case Phase::LongBreak:  return kLongBreakSeconds;
    }
    return kFocusSeconds; // unreachable, but compilers want proof
}

void PomodoroPage::advancePhase()
{
    // The transition table, straight from the prototype:
    //   Focus -> Short break (rounds 1–3) or Long break (round 4)
    //   any break -> Focus, and the round counter advances.
    if (m_phase == Phase::Focus) {
        m_phase = (m_round % kRoundsPerCycle == 0) ? Phase::LongBreak
                                                   : Phase::ShortBreak;
    } else {
        m_phase = Phase::Focus;
        ++m_round;
    }
    m_remaining = phaseTotalSeconds();
}

void PomodoroPage::tick()
{
    if (--m_remaining <= 0)
        advancePhase();
    refresh();
}

void PomodoroPage::toggleRunning()
{
    m_running = !m_running;
    if (m_running)
        m_timer.start();
    else
        m_timer.stop();
    refresh();
}

void PomodoroPage::reset()
{
    m_running = false;
    m_timer.stop();
    m_phase = Phase::Focus;
    m_round = 1;
    m_remaining = kFocusSeconds;
    refresh();
}

void PomodoroPage::skip()
{
    advancePhase();
    refresh();
}

void PomodoroPage::refresh()
{
    const QColor color =
        (m_phase == Phase::Focus) ? theme::focus() : theme::brk();
    const QString phaseName = (m_phase == Phase::Focus) ? tr("Focus")
        : (m_phase == Phase::ShortBreak)                ? tr("Short break")
                                                        : tr("Long break");

    m_phaseLabel->setText(phaseName);
    m_phaseLabel->setStyleSheet(
        QStringLiteral("font-size:17px; font-weight:800; color:%1;")
            .arg(color.name()));

    const int total = phaseTotalSeconds();
    const double progress = 1.0 - double(m_remaining) / double(total);
    const QString timeText =
        QStringLiteral("%1:%2")
            .arg(m_remaining / 60, 2, 10, QChar('0'))
            .arg(m_remaining % 60, 2, 10, QChar('0'));
    m_ring->setState(progress, timeText, tr("Round %1").arg(m_round), color);

    // Dots: done rounds solid green, the current one haloed, future grey.
    const int currentIndex = (m_round - 1) % kRoundsPerCycle;
    for (int i = 0; i < m_dots.size(); ++i) {
        QString style = QStringLiteral("border-radius:5px; background:%1;");
        if (i < currentIndex)
            style = style.arg(theme::focus().name());
        else if (i == currentIndex && m_phase == Phase::Focus)
            style = style.arg(theme::focus().name())
                    + "border: 2px solid rgba(47,126,110,0.35);";
        else
            style = style.arg(theme::track().name());
        m_dots[i]->setStyleSheet(style);
    }

    m_startBtn->setText(m_running ? tr("Pause") : tr("Start"));
}

// ---- PomodoroRing ------------------------------------------------------------

PomodoroRing::PomodoroRing(QWidget* parent)
    : QWidget(parent)
{
    setFixedSize(sizeHint());
}

void PomodoroRing::setState(double progress, const QString& timeText,
                            const QString& roundText, const QColor& color)
{
    m_progress  = progress;
    m_timeText  = timeText;
    m_roundText = roundText;
    m_color     = color;
    update();
}

void PomodoroRing::paintEvent(QPaintEvent*)
{
    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing);

    const int stroke = 14;
    const QRectF r = QRectF(rect()).adjusted(stroke / 2 + 1, stroke / 2 + 1,
                                             -stroke / 2 - 1, -stroke / 2 - 1);

    // Track circle, then the progress arc on top. Qt measures arcs in
    // 1/16ths of a degree from 3 o'clock, counter-clockwise; we start at
    // 12 o'clock (90*16) and sweep clockwise (negative span).
    QPen pen(theme::track(), stroke, Qt::SolidLine, Qt::RoundCap);
    p.setPen(pen);
    p.drawEllipse(r);

    if (m_progress > 0.0) {
        pen.setColor(m_color);
        p.setPen(pen);
        p.drawArc(r, 90 * 16, int(-m_progress * 360.0 * 16.0));
    }

    // A multiplied size needs the same guard as a subtracted one:
    const qreal basePts = font().pointSizeF() > 0 ? font().pointSizeF() : 10.0;
    p.setFont(scaledFont(font(), basePts * 1.6, /*bold=*/true));
    p.setPen(theme::ink());
    p.drawText(rect().adjusted(0, -10, 0, -10), Qt::AlignCenter, m_timeText);

    p.setFont(scaledFont(font(), -1));
    p.setPen(theme::inkSoft());
    p.drawText(rect().adjusted(0, 44, 0, 0), Qt::AlignCenter, m_roundText);
}
