#include "PickActivityDialog.h"

#include "Theme.h"
#include "Widgets.h"
#include "../domain/AppData.h"

#include <QHBoxLayout>
#include <QLabel>
#include <QListWidget>
#include <QPushButton>
#include <QVBoxLayout>

PickActivityDialog::PickActivityDialog(const AppData* data, QDate date,
                                       int slotIndex, QWidget* parent)
    : QDialog(parent)
    , m_data(data)
    , m_date(date)
    , m_slotIndex(slotIndex)
{
    setWindowTitle(tr("Plan a block"));
    setMinimumWidth(400);

    auto* layout = new QVBoxLayout(this);
    layout->setContentsMargins(20, 18, 20, 18);
    layout->setSpacing(10);

    auto* title = new QLabel(
        tr("What are you doing at %1?").arg(timeLabel(chosenStartMinutes())),
        this);
    title->setObjectName("h2");
    auto* sub = new QLabel(
        tr("Pick how long you're planning, then choose the activity."), this);
    sub->setObjectName("sub");

    auto* pillHost = new QWidget(this);
    buildDurationPills(pillHost);

    m_list = new QListWidget(this);
    m_list->setSelectionMode(QAbstractItemView::SingleSelection);
    buildActivityList();
    connect(m_list, &QListWidget::itemClicked,
            this, &PickActivityDialog::onItemClicked);

    layout->addWidget(title);
    layout->addWidget(sub);
    layout->addWidget(pillHost);
    layout->addWidget(m_list, /*stretch=*/1);
}

int PickActivityDialog::chosenStartMinutes() const
{
    return plan::kDayStartMinutes + m_slotIndex * plan::kSlotMinutes;
}

int PickActivityDialog::chosenEndMinutes() const
{
    return chosenStartMinutes() + m_durationSlots * plan::kSlotMinutes;
}

int PickActivityDialog::maxFreeSlots() const
{
    // Walk downward from the clicked slot while it stays free — that run,
    // capped at 2 h, is how long the new block may be. The check delegates
    // to AppData::isFree: the overlap rule exists in ONE place only.
    int run = 0;
    for (int i = m_slotIndex;
         i < plan::kSlotsPerDay && run < plan::kMaxSlotsPerEvent; ++i) {
        const int start = plan::kDayStartMinutes + i * plan::kSlotMinutes;
        if (!m_data->isFree(m_date, start, start + plan::kSlotMinutes))
            break;
        ++run;
    }
    return qMax(1, run);
}

void PickActivityDialog::buildDurationPills(QWidget* host)
{
    auto* row = new QHBoxLayout(host);
    row->setContentsMargins(0, 0, 0, 0);
    row->setSpacing(8);

    const int cap = maxFreeSlots();
    m_durationSlots = qMin(m_durationSlots, cap);

    for (int slotCount = 1; slotCount <= cap; ++slotCount) {
        auto* pill = new QPushButton(durationLabel(slotCount), host);
        pill->setObjectName("segment");
        pill->setCheckable(true);
        pill->setChecked(slotCount == m_durationSlots);
        pill->setCursor(Qt::PointingHandCursor);

        // Lambda capturing `slotCount` BY VALUE: each button remembers its own
        // number. Capture by reference here would be a classic bug — all
        // pills would share the loop variable's final value.
        connect(pill, &QPushButton::clicked, this, [this, slotCount]() {
            m_durationSlots = slotCount;
            for (int i = 0; i < m_pills.size(); ++i)
                m_pills[i]->setChecked(i + 1 == slotCount);
        });
        m_pills.append(pill);
        row->addWidget(pill);
    }
}

void PickActivityDialog::buildActivityList()
{
    // Activities grouped under their category, exactly like the prototype's
    // picker. Category headers are items with interaction flags removed —
    // visible structure, not clickable choices.
    for (const Category& c : m_data->categories()) {
        bool headerAdded = false;
        for (const Activity& a : m_data->activities()) {
            if (a.categoryId != c.id)
                continue;
            if (!headerAdded) {
                auto* header = new QListWidgetItem(c.name.toUpper(), m_list);
                header->setFlags(Qt::NoItemFlags); // not selectable/clickable
                header->setFont(scaledFont(m_list->font(), -2, /*bold=*/true));
                header->setForeground(theme::inkSoft());
                headerAdded = true;
            }
            auto* item = new QListWidgetItem(QIcon(colorDot(c.color)), a.name,
                                             m_list);
            // The id rides along INSIDE the item (Qt::UserRole) — no
            // parallel array to keep in sync with the visible list.
            item->setData(Qt::UserRole, a.id);
        }
    }

    if (m_list->count() == 0) {
        auto* empty = new QListWidgetItem(
            tr("No activities yet — add some in the Activities tab first."),
            m_list);
        empty->setFlags(Qt::NoItemFlags);
        empty->setForeground(theme::inkSoft());
    }
}

void PickActivityDialog::onItemClicked(QListWidgetItem* item)
{
    const QString id = item->data(Qt::UserRole).toString();
    if (id.isEmpty())
        return; // a header or the empty-state row
    m_activityId = id;
    accept(); // one click chooses AND confirms — prototype behaviour
}
