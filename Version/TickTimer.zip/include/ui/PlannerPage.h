#pragma once
// ---------------------------------------------------------------------------
// PlannerPage — the Calendar tab. It composes the pieces you've already
// read (AgendaWidget, GlancePanel, WeekReviewPage, MonthReviewPage) and
// adds the top bar: ‹ date › navigation plus the Day/Week/Month switch.
//
// This class is a COORDINATOR, and that is a role worth recognizing: it
// owns almost no logic of its own. It holds the current date, decides
// which sub-view is visible, and translates the agenda's signals ("slot 7
// was clicked") into use-case steps ("open the picker; if accepted, ask
// AppData to add the event"). Everything else is delegated.
//
// UC1 lives here end to end: click a free slot -> PickActivityDialog ->
// AppData::addEvent -> changed() -> every widget repaints. Follow that
// chain once in the debugger and you'll understand the whole app's
// update model.
// ---------------------------------------------------------------------------

#include <QDate>
#include <QWidget>

class AppData;
class TrackerService;
class AgendaWidget;
class GlancePanel;
class WeekReviewPage;
class MonthReviewPage;
class QLabel;
class QPushButton;
class QStackedWidget;

class PlannerPage : public QWidget
{
    Q_OBJECT

public:
    PlannerPage(AppData* data, TrackerService* tracker,
                QWidget* parent = nullptr);

private slots:
    void shiftPeriod(int direction);   // -1 = previous, +1 = next
    void setMode(int mode);            // 0 day, 1 week, 2 month
    void onEmptySlotClicked(int slotIndex);
    void onEventClicked(const QString& eventId);
    void refresh();

private:
    void updatePeriodLabel();

    AppData*        m_data;
    TrackerService* m_tracker;
    QDate m_date;                      // the day (or a day inside the
    int   m_mode = 0;                  //  week/month) being viewed

    QLabel*         m_periodLabel = nullptr;
    QStackedWidget* m_stack       = nullptr;
    AgendaWidget*   m_agenda      = nullptr;
    GlancePanel*    m_glance      = nullptr;
    WeekReviewPage* m_week        = nullptr;
    MonthReviewPage* m_month      = nullptr;
    QVector<QPushButton*> m_modeButtons;
};
