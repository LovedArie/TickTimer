#pragma once
// ---------------------------------------------------------------------------
// MainWindow — the composition root: the ONE place where the app's parts
// are created and wired together.
//
// Ownership picture (worth drawing once and remembering forever):
//
//   MainWindow
//    ├── AppData        (the data, and its rules)
//    ├── JsonStore      (how the data reaches the disk)
//    ├── TrackerService (the live timer)
//    └── pages: PlannerPage / ActivitiesPage / PomodoroPage
//                └── every page gets POINTERS to the above, never copies
//
// Everything lives exactly as long as the window. Pages borrow, never own.
// When a novice asks "who deletes what?", THIS diagram is the answer —
// and most of it is Qt's parent-child tree doing the deleting.
//
// The save wiring is one line with big consequences:
//     connect(data.changed -> store.save)
// After that, no code anywhere ever calls "save" explicitly. Every legal
// mutation, wherever it came from, reaches the disk. Forgetting to save
// is now structurally impossible — the design-doc §4 strategy realized.
// ---------------------------------------------------------------------------

#include "../domain/AppData.h"
#include "../storage/JsonStore.h"
#include "../tracking/TrackerService.h"

#include <QMainWindow>

class QStackedWidget;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow();

protected:
    // The window's close is our shutdown hook: commit any live interval,
    // final save, then let the close proceed.
    void closeEvent(QCloseEvent* event) override;

private:
    // Declaration ORDER matters here, and it's a genuine C++ lesson:
    // members are constructed top-to-bottom and destroyed bottom-to-top.
    // TrackerService holds a pointer to AppData, so AppData is declared
    // FIRST (born first, dies last) — the tracker can never outlive the
    // data it points into.
    AppData        m_data;
    JsonStore      m_store;
    TrackerService m_tracker;

    QStackedWidget* m_pages = nullptr;
};
