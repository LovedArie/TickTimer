#pragma once
// ---------------------------------------------------------------------------
// ActivitiesPage — manage life areas and activities (UC3): one card per
// category listing its activities, add/delete for both, colour picking.
//
// UPDATE STRATEGY — rebuild, don't patch: whenever the data changes, this
// page throws its whole content away and builds it again from AppData.
// For a dataset of dozens of items that's instant, and it is IMPOSSIBLE
// for the screen to show stale state, because there is no incremental
// patching code to get wrong. (The grown-up alternative — Qt's model/view
// framework with QAbstractItemModel — earns its complexity at thousands
// of rows; a deliberate later lesson, not a v1 need.)
//
// Notice how the integrity rules SHOW UP here without being enforced here:
// an in-use activity gets an "in use (3)" tag instead of a ✕; a non-empty
// category gets a count instead of a Delete. The UI mirrors rules that
// live in AppData — remove these guards and the data would still be safe,
// just the user would meet a refusal instead of not meeting a button.
// ---------------------------------------------------------------------------

#include <QWidget>

class AppData;
class QLineEdit;
class QPushButton;
class QScrollArea;

class ActivitiesPage : public QWidget
{
    Q_OBJECT

public:
    explicit ActivitiesPage(AppData* data, QWidget* parent = nullptr);

public slots:
    void rebuild();

private:
    QWidget* buildContent(); // fresh content widget from current data

    AppData*     m_data;
    QScrollArea* m_scroll = nullptr;
    QColor       m_newCategoryColor{"#4C6FE0"};
};
