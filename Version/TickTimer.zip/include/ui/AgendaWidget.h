#pragma once
// ---------------------------------------------------------------------------
// AgendaWidget — the day timeline: 36 half-hour slots from 6 AM to midnight,
// with planned Events drawn as coloured blocks (the prototype's agenda).
//
// This is your first fully CUSTOM-PAINTED Qt widget, and it teaches the
// pattern behind every chart and calendar you'll ever build in Qt:
//
//   1. paintEvent(): draw the current state with QPainter. Never cache
//      pixels, never mutate state here — just read data and draw it.
//   2. mouse events: turn a click position back into a MEANING ("slot 7",
//      "event e42") with the same geometry math, then emit a signal.
//   3. update(): whenever the data changes, schedule a repaint. Qt calls
//      paintEvent again and the widget redraws from scratch.
//
// The widget renders; the PAGE decides what a click means. That's why it
// emits signals instead of opening dialogs itself — it stays reusable and
// ignorant of the rest of the app.
// ---------------------------------------------------------------------------

#include <QDate>
#include <QWidget>

class AppData;
class TrackerService;
class Event;

class AgendaWidget : public QWidget
{
    Q_OBJECT

public:
    AgendaWidget(const AppData* data, const TrackerService* tracker,
                 QWidget* parent = nullptr);

    void setDate(QDate date);
    QDate date() const { return m_date; }

signals:
    void emptySlotClicked(int slotIndex);      // "plan something at 9:00"
    void eventClicked(const QString& eventId); // "open this block"

protected:
    // `override` (C++11) makes the compiler VERIFY we are really overriding
    // a virtual from QWidget — a typo in the signature becomes a compile
    // error instead of a silently-never-called function.
    void paintEvent(QPaintEvent* event) override;
    void mousePressEvent(QMouseEvent* event) override;
    void mouseMoveEvent(QMouseEvent* event) override;
    void leaveEvent(QEvent* event) override;
    QSize sizeHint() const override;

private:
    QRect eventRect(const Event& e) const; // one geometry rule, used by
    int   slotAt(const QPoint& pos) const; // paint AND hit-testing alike

    const AppData*        m_data;    // read-only view of the data
    const TrackerService* m_tracker; // for the live-growing mini bar
    QDate m_date;
    int   m_hoverSlot = -1;          // empty slot under the mouse, or -1
};
