#pragma once
// ---------------------------------------------------------------------------
// Theme — the prototype's colour palette and the app-wide stylesheet.
//
// WHY one file: the prototype defined its palette once as CSS variables
// (--focus, --break, ...) and every element referenced them. This is the
// C++ twin of that idea. Change "focus green" here and every widget,
// chart, and button follows. Scattered hex literals are how UIs drift
// into inconsistency.
//
// Qt Style Sheets (QSS) are deliberately CSS-like, so most of the
// prototype's styling translates almost line for line.
// ---------------------------------------------------------------------------

#include <QColor>
#include <QString>

namespace theme
{
inline const QColor bg()      { return QColor("#F1F4F0"); }
inline const QColor surface() { return QColor("#FFFFFF"); }
inline const QColor ink()     { return QColor("#272C33"); }
inline const QColor inkSoft() { return QColor("#616974"); }
inline const QColor line()    { return QColor("#E2E6E0"); }
inline const QColor focus()   { return QColor("#2F7E6E"); } // calm green
inline const QColor brk()     { return QColor("#DD9B4A"); } // warm amber
inline const QColor track()   { return QColor("#EAEDE8"); } // empty bar
inline const QColor danger()  { return QColor("#C25B54"); }

inline QString appStyleSheet()
{
    return QStringLiteral(R"CSS(
        QMainWindow, QDialog { background: #F1F4F0; }
        QWidget { color: #272C33; font-size: 13px; }

        /* Cards/panels — objectName selector, like a CSS class */
        QFrame#panel {
            background: #FFFFFF;
            border: 1px solid #E2E6E0;
            border-radius: 14px;
        }
        QLabel#h1 { font-size: 19px; font-weight: 800; }
        QLabel#h2 { font-size: 15px; font-weight: 700; }
        QLabel#sub { color: #616974; font-size: 12px; }
        QLabel#stateIdle     { color: #616974; font-weight: 600; }
        QLabel#stateFocusing { color: #2F7E6E; font-weight: 600; }
        QLabel#stateOnBreak  { color: #DD9B4A; font-weight: 600; }
        QLabel#encourage {
            background: rgba(47,126,110,0.08);
            color: #245F53;
            border-radius: 10px;
            padding: 10px 12px;
            font-size: 12px;
        }

        /* Left navigation */
        QToolButton#nav {
            border: none; border-radius: 10px;
            padding: 9px 14px;
            font-weight: 700; font-size: 13px;
            color: #616974; background: transparent;
            text-align: left;
        }
        QToolButton#nav:hover   { background: rgba(47,126,110,0.07); color: #272C33; }
        QToolButton#nav:checked { background: rgba(47,126,110,0.12); color: #2F7E6E; }

        /* Buttons */
        QPushButton {
            background: #FFFFFF; border: 1px solid #E2E6E0;
            border-radius: 9px; padding: 7px 13px; font-weight: 600;
        }
        QPushButton:hover:enabled { border-color: #2F7E6E; color: #2F7E6E; }
        QPushButton:disabled { color: #AEB4AC; }
        QPushButton#primary {
            background: #2F7E6E; border: none; color: white; padding: 9px 15px;
        }
        QPushButton#primary:hover:enabled { background: #2A7263; color: white; }
        QPushButton#breakBtn {
            background: #DD9B4A; border: none; color: white; padding: 9px 15px;
        }
        QPushButton#breakBtn:hover:enabled { background: #D08F3E; color: white; }
        QPushButton#quiet {
            background: #EEF0ED; border: none; padding: 9px 15px;
        }
        QPushButton#danger {
            background: transparent; border: none; color: #C25B54;
            font-size: 12px; padding: 4px;
        }
        QPushButton#segment {
            border-radius: 0px; border: 1px solid #E2E6E0; padding: 7px 16px;
            background: #FFFFFF; color: #616974; font-size: 12px;
        }
        QPushButton#segment:checked { background: #2F7E6E; color: white; border-color: #2F7E6E; }

        QLineEdit, QPlainTextEdit {
            background: #FFFFFF; border: 1px solid #E2E6E0;
            border-radius: 9px; padding: 7px 10px;
        }
        QLineEdit:focus, QPlainTextEdit:focus { border-color: #2F7E6E; }

        QListWidget { border: none; background: transparent; }
        QScrollArea { border: none; background: transparent; }
        QStatusBar { color: #616974; }
    )CSS");
    // R"CSS(...)CSS" is a C++11 raw string literal: no escaping of quotes
    // or newlines — ideal for embedding a stylesheet.
}
} // namespace theme
