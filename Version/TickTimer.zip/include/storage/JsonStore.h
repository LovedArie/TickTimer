#pragma once
// ---------------------------------------------------------------------------
// JsonStore — saves and loads the whole AppData as one JSON file
// (design-doc §4: load on startup, hold in memory, write back on change).
//
// SEPARATION OF CONCERNS, the architectural point of this file:
// the domain structs know NOTHING about JSON. All to/from-JSON knowledge is
// concentrated here, in the storage layer. The day we outgrow JSON and move
// to SQLite (a planned upgrade, design-doc §4), we write an SqliteStore and
// delete this file — Category, Event, AppData, and every screen stay
// untouched. Persistence is a detail; the domain is the point.
//
// WHY JSON for v1 (design-doc §4): zero setup, human-readable — you can
// open your own data file in a text editor and *see* your day, which is
// worth gold while debugging. Qt reads and writes it natively
// (QJsonDocument), so no third-party dependency.
// ---------------------------------------------------------------------------

#include <QString>

class AppData;

class JsonStore
{
public:
    explicit JsonStore(QString filePath);

    // The OS-blessed place for app data (QStandardPaths). On Windows:
    // C:/Users/<you>/AppData/Roaming/TimeFocusTracker/data.json
    // On Linux:   ~/.local/share/TimeFocusTracker/data.json
    // Never hard-code such paths — every OS has its own convention.
    static QString defaultFilePath();

    const QString& filePath() const { return m_filePath; }

    // true  = data was loaded from an existing file
    // false = no file yet (first run — caller should seed defaults) or the
    //         file was unreadable (errorMessage() says which).
    bool load(AppData& data);

    bool save(const AppData& data);

    QString errorMessage() const { return m_error; }

private:
    QString m_filePath;
    QString m_error;
};
