#pragma once
// ---------------------------------------------------------------------------
// TrackerService — the live focus/break timer (UC2), the app's core value.
//
// This is the state machine from design-doc §3.8, "timer state as state,
// not subclasses": one State enum field, not an IdleTracker/FocusingTracker
// class hierarchy (Larman ch. 32 — states as subclasses cause a class
// explosion).
//
//                startFocus              startBreak
//        Idle ─────────────▶ Focusing ◀─────────────▶ OnBreak
//          ▲                    │        startFocus      │
//          └────── stop ────────┴──────── stop ──────────┘
//
// Every transition OUT of Focusing/OnBreak commits the interval that just
// ended as a Segment (real start & end timestamps) into the Event.
//
// WHY the live segment is NOT stored inside the Event while it runs: an
// open-ended, still-growing segment in the domain data would force every
// reader (stats, charts, save) to special-case "unless it's still running".
// Instead the domain holds only FINISHED facts; the in-flight interval
// lives here, plus its crash-insurance copy in AppData::running() (a tiny
// {eventId, kind, start, lastSeen} block, heartbeat-refreshed and saved).
//
// WHY a service object separate from the UI: the timer must keep running
// when the event dialog closes, when you switch to the Pomodoro tab —
// its lifetime is the app's, not any window's. One instance, owned by
// MainWindow, shared by reference with any screen that needs it.
// ---------------------------------------------------------------------------

#include "../domain/Segment.h"

#include <QDateTime>
#include <QObject>
#include <QString>
#include <QTimer>

class AppData;

class TrackerService : public QObject
{
    Q_OBJECT

public:
    enum class State { Idle, Focusing, OnBreak };

    explicit TrackerService(AppData* data, QObject* parent = nullptr);

    State   state() const           { return m_state; }
    QString trackedEventId() const  { return m_eventId; }
    bool    isTrackingEvent(const QString& eventId) const
    {
        return m_state != State::Idle && m_eventId == eventId;
    }

    // Seconds of the CURRENT, uncommitted interval — the UI adds this on
    // top of the committed totals so numbers grow live on screen.
    qint64 liveSeconds() const;

public slots:
    // Starting on event B while tracking event A is legal: A's interval is
    // committed first, then B starts. One timer, app-wide, by design — you
    // are one person; you cannot focus on two blocks at once.
    void startFocus(const QString& eventId);
    void startBreak(const QString& eventId);
    void stop();

signals:
    void stateChanged(); // Idle/Focusing/OnBreak flipped, or target moved
    void tick();         // once per second while tracking — repaint cue

private:
    void beginInterval(const QString& eventId, SegmentKind kind);
    void commitCurrentInterval(); // finished fact -> Segment -> AppData

    AppData*  m_data = nullptr;   // not owned; owned by MainWindow
    State     m_state = State::Idle;
    QString   m_eventId;
    SegmentKind m_kind = SegmentKind::Focus;
    QDateTime m_startedAt;

    QTimer m_secondTimer;    // drives tick() for live UI updates
    QTimer m_heartbeatTimer; // refreshes crash insurance every 30 s
};
