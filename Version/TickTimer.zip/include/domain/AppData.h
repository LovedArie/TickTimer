#pragma once
// ---------------------------------------------------------------------------
// AppData — the single owner of ALL the application's data, and the only
// door through which that data may be changed.
//
// Design pattern: this is an *aggregate root* guarding its invariants.
// The Supplementary Specification's integrity rules —
//   - an Activity used by any Event cannot be deleted,
//   - a Category can only be deleted once it holds no Activities,
//   - two Events on the same day cannot overlap —
// are enforced HERE, in the mutation methods, not in the UI. If the rules
// lived in the UI, every new screen (and the future Android UI!) would have
// to re-implement them, and one day one screen would forget. Put the law
// where the data lives, and no caller can break it.
//
// That is also WHY the containers are private with read-only accessors,
// while Category/Activity/Event themselves are open structs: THIS class has
// invariants to defend; they don't.
//
// WHY AppData is a QObject: for one thing only — the `changed()` signal.
// Qt's signals & slots are the framework's built-in Observer pattern.
// Every mutation ends with `emit changed()`, and whoever cares (the UI
// repaints, the JsonStore saves) subscribes with `connect(...)`. AppData
// never knows the UI exists — the dependency points strictly downward.
// ---------------------------------------------------------------------------

#include "Activity.h"
#include "Category.h"
#include "Event.h"

#include <QObject>
#include <QVector>

#include <optional>

// Crash insurance for the live timer (Supplementary Spec, Reliability):
// while a Focus/Break timer runs, WHAT is running is persisted as this
// little block. `lastSeen` is refreshed by a heartbeat every ~30 s. If the
// app dies, the next launch finds this block and converts [start..lastSeen]
// into a real Segment — at most ~30 s of the in-progress interval is lost.
struct RunningState
{
    QString     eventId;
    SegmentKind kind = SegmentKind::Focus;
    QDateTime   start;
    QDateTime   lastSeen;
};

class AppData : public QObject
{
    Q_OBJECT // enables signals/slots; processed by Qt's moc tool at build time

public:
    explicit AppData(QObject* parent = nullptr);

    // ---- read access -----------------------------------------------------
    // const& = "look, don't touch": callers can iterate but cannot mutate,
    // so no code path can bypass the rules below.
    const QVector<Category>& categories() const { return m_categories; }
    const QVector<Activity>& activities() const { return m_activities; }
    const QVector<Event>&    events()     const { return m_events; }

    // Lookups by id. They return POINTERS because "not found" must be
    // representable (nullptr). LIFETIME RULE, and it matters: the pointer is
    // valid only until the next mutation — QVector may move its elements in
    // memory when it changes. Look up, use, let go; never store one.
    const Category* categoryById(const QString& id) const;
    const Activity* activityById(const QString& id) const;
    const Event*    eventById(const QString& id) const;

    QVector<const Event*> eventsOn(QDate date) const;   // sorted by start time
    int  activityCountIn(const QString& categoryId) const;
    int  eventCountUsing(const QString& activityId) const;
    bool isFree(QDate date, int startMin, int endMin,
                const QString& ignoreEventId = QString()) const;

    // ---- mutations (each ends with `emit changed()`) ----------------------
    // They return the new id, or bool for success — and REFUSE illegal
    // operations instead of trusting the caller. The UI's job is merely to
    // make illegal operations hard to reach (e.g. hide the delete button);
    // the domain's job is to make them impossible.
    QString addCategory(const QString& name, const QColor& color);
    bool    renameCategory(const QString& id, const QString& name);
    bool    recolorCategory(const QString& id, const QColor& color);
    bool    removeCategory(const QString& id);          // fails if it has activities

    QString addActivity(const QString& name, const QString& categoryId);
    bool    removeActivity(const QString& id);          // fails if any Event uses it

    QString addEvent(QDate date, int startMin, int endMin,
                     const QString& activityId);        // fails on overlap -> ""
    bool    moveEvent(const QString& id, int newStartMin); // keeps duration
    bool    setEventNote(const QString& id, const QString& note);
    bool    removeEvent(const QString& id);
    bool    appendSegment(const QString& eventId, const Segment& segment);

    // ---- live-timer crash insurance ---------------------------------------
    const std::optional<RunningState>& running() const { return m_running; }
    void setRunning(const RunningState& state);
    void touchRunning(const QDateTime& lastSeen);       // heartbeat
    void clearRunning();

    // Called once after load(). If a RunningState survived a crash, turn it
    // into a real Segment and report what happened (message for the UI).
    QString recoverInterruptedTracking();

    // ---- used only by JsonStore when loading -------------------------------
    // Loading replaces everything wholesale; it is not a user edit, so it
    // deliberately does NOT emit changed() (the caller refreshes explicitly —
    // otherwise loading would immediately trigger a pointless save).
    void resetFrom(QVector<Category> categories,
                   QVector<Activity> activities,
                   QVector<Event> events,
                   std::optional<RunningState> running);

    // First-run seed: the five life areas and starter activities the
    // prototype validated, so the app never greets you with an empty void.
    void seedDefaults();

signals:
    void changed(); // "something is different — repaint / save yourselves"

private:
    Event* mutableEventById(const QString& id); // private: edits stay in-house

    QVector<Category> m_categories;
    QVector<Activity> m_activities;
    QVector<Event>    m_events;

    // std::optional (C++17): a value that may legitimately be absent.
    // Clearer and safer than a magic "empty id means nothing is running".
    std::optional<RunningState> m_running;
};
