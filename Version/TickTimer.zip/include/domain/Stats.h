#pragma once
// ---------------------------------------------------------------------------
// Stats — DERIVE, DON'T STORE (design-doc §3.5), as code.
//
// There is deliberately no DaySummary object saved anywhere, no WeeklyTotal
// field kept up to date. Every number any screen shows is computed here,
// on demand, from the raw Segments. A stored summary can drift out of sync
// with the raw data and start lying; a derived one cannot.
//
// WHY free functions in a namespace, not methods on AppData: summarising
// only READS the data — it needs no privileged access and defends no
// invariant. Keeping it out of AppData keeps that class focused on its one
// job (guarding mutations) and keeps these functions trivially testable:
// in, data; out, numbers; no state anywhere.
// ---------------------------------------------------------------------------

#include "AppData.h"

#include <QDate>
#include <QMap>
#include <QString>
#include <QVector>

namespace stats
{

struct Totals
{
    qint64 focusSeconds = 0;
    qint64 breakSeconds = 0;
    qint64 total() const { return focusSeconds + breakSeconds; }
};

// Totals for a single Event (only committed Segments; the second-by-second
// live extra is the TrackerService's business and is added by the UI).
Totals eventTotals(const Event& event);

struct PeriodSummary
{
    Totals totals;                        // focus vs break over the period
    QMap<QString, qint64> byCategory;     // categoryId -> tracked seconds
    QVector<QPair<QDate, Totals>> byDay;  // one entry per day, in order
};

// One function covers day, week, and month — the period is just [from..to].
// The date dimension comes from each Event's date, exactly as the domain
// model intended ("a day is just the Events whose date matches").
PeriodSummary summarize(const AppData& data, QDate from, QDate to);

// Convenience wrappers so call sites read like the requirement they serve.
PeriodSummary summarizeDay(const AppData& data, QDate day);
PeriodSummary summarizeWeek(const AppData& data, QDate anyDayInWeek);  // Mon..Sun
PeriodSummary summarizeMonth(const AppData& data, QDate anyDayInMonth);

// "2h 05m" / "12m" / "45s" — one formatter used everywhere, so durations
// look identical on every screen.
QString formatSeconds(qint64 seconds);

} // namespace stats
