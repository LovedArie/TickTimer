// ---------------------------------------------------------------------------
// test_auth.cpp — the security-critical layer gets the most careful tests in
// the project, because a bug here doesn't crash, it silently lets the wrong
// person in. Every property that MUST hold for credential storage is pinned.
// ---------------------------------------------------------------------------

#include "JsonStore.h"
#include "AppData.h"
#include "AccountStore.h"
#include "PlannerStore.h"
#include "SyncPlan.h"
#include "PasswordHash.h"

#include <QJsonObject>
#include <QColor>
#include <QDateTime>
#include <QDir>
#include <qscopeguard.h>
#include <QTemporaryDir>
#include <QtTest>

class TestAuth : public QObject
{
    Q_OBJECT

private slots:
    void hashIsNeverThePlaintext()
    {
        const QString stored = auth::hashPassword("hunter2");
        // The stored string must not contain the password anywhere — the
        // single most important property, checked first.
        QVERIFY(!stored.contains("hunter2"));
        QVERIFY(stored.startsWith("pbkdf2$")); // self-describing format
    }

    void samePasswordHashesDifferentlyEachTime()
    {
        // Distinct random salts → distinct stored strings for identical
        // passwords. Without this, a stolen file reveals which users share a
        // password, and rainbow tables crack them all at once.
        const QString a = auth::hashPassword("same-password");
        const QString b = auth::hashPassword("same-password");
        QVERIFY(a != b);
        // …yet BOTH must verify against the one password.
        QVERIFY(auth::verifyPassword("same-password", a));
        QVERIFY(auth::verifyPassword("same-password", b));
    }

    void verifyRejectsWrongPasswordAndGarbage()
    {
        const QString stored = auth::hashPassword("correct horse");
        QVERIFY(!auth::verifyPassword("wrong horse", stored));
        // Malformed stored strings are a failed verification, never a crash.
        QVERIFY(!auth::verifyPassword("x", "not-a-valid-hash"));
        QVERIFY(!auth::verifyPassword("x", ""));
        QVERIFY(!auth::verifyPassword("x", "pbkdf2$notanumber$aa$bb"));
    }

    void registerThenLogin()
    {
        QTemporaryDir dir;
        AccountStore store(dir.filePath("accounts.json"));

        QCOMPARE(store.registerAccount("alice", "s3cret"),
                 AccountStore::Result::Ok);
        QCOMPARE(store.login("alice", "s3cret"),
                 AccountStore::Result::Ok);
        QCOMPARE(store.login("alice", "wrong"),
                 AccountStore::Result::WrongPassword);
        QCOMPARE(store.login("bob", "whatever"),
                 AccountStore::Result::UsernameNotFound);
    }

    void duplicateNamesAreRefusedCaseInsensitively()
    {
        QTemporaryDir dir;
        AccountStore store(dir.filePath("accounts.json"));
        QCOMPARE(store.registerAccount("Alice", "pw1"),
                 AccountStore::Result::Ok);
        // "alice" is "Alice" — refused, and login works under either casing.
        QCOMPARE(store.registerAccount("alice", "pw2"),
                 AccountStore::Result::UsernameTaken);
        QCOMPARE(store.login("ALICE", "pw1"),
                 AccountStore::Result::Ok);
    }

    void emptyCredentialsRefused()
    {
        QTemporaryDir dir;
        AccountStore store(dir.filePath("accounts.json"));
        QCOMPARE(store.registerAccount("", "pw"),
                 AccountStore::Result::InvalidInput);
        QCOMPARE(store.registerAccount("name", ""),
                 AccountStore::Result::InvalidInput);
    }

    void accountsPersistAcrossReload()
    {
        QTemporaryDir dir;
        const QString path = dir.filePath("accounts.json");
        {
            AccountStore store(path);
            store.registerAccount("carol", "pw");
        }
        // A brand-new store reading the same file must find carol — and her
        // password must still verify (the HASH round-tripped, not the
        // plaintext, which was never written).
        AccountStore reloaded(path);
        QVERIFY(reloaded.hasUser("carol"));
        QCOMPARE(reloaded.login("carol", "pw"),
                 AccountStore::Result::Ok);
    }

    void usernamesMustBeFilenameSafe()
    {
        // Usernames become server-side FILENAMES (planners/<name>.json), so
        // the charset is enforced at registration. "../x" is a username
        // somebody will try; it must die at the door, not in the file system.
        QTemporaryDir dir;
        AccountStore store(dir.filePath("accounts.json"));
        QCOMPARE(store.registerAccount("../etc", "pw"),
                 AccountStore::Result::InvalidInput);
        QCOMPARE(store.registerAccount("we/ird", "pw"),
                 AccountStore::Result::InvalidInput);
        QCOMPARE(store.registerAccount("has space", "pw"),
                 AccountStore::Result::InvalidInput);
        QCOMPARE(store.registerAccount("fine_name-2", "pw"),
                 AccountStore::Result::Ok);
    }

    void plannerStoreVersionsDocuments()
    {
        QTemporaryDir dir;
        PlannerStore store(dir.path());

        // Nothing stored yet: revision 0 and an empty document — the state a
        // fresh account and a fresh device both agree on.
        QCOMPARE(store.revision("alice"), 0);
        QVERIFY(store.planner("alice").isEmpty());

        QJsonObject doc;
        doc[QStringLiteral("marker")] = 1;
        QCOMPARE(store.store("alice", doc), 1);       // first store → rev 1
        QCOMPARE(store.revision("alice"), 1);
        QCOMPARE(store.planner("alice")
                     .value(QStringLiteral("marker")).toInt(), 1);

        doc[QStringLiteral("marker")] = 2;
        QCOMPARE(store.store("alice", doc), 2);       // every store bumps

        // Case-insensitive identity: "Alice" is alice's shelf, not a new one.
        QCOMPARE(store.revision("Alice"), 2);

        // Per-user isolation: bob's shelf is untouched by alice's activity.
        QCOMPARE(store.revision("bob"), 0);
        QVERIFY(store.planner("bob").isEmpty());

        // Persistence: a fresh store over the same directory sees the same
        // shelf — revisions are on disk, not in memory.
        PlannerStore reloaded(dir.path());
        QCOMPARE(reloaded.revision("alice"), 2);
    }

    void syncDecisionTruthTable()
    {
        // The ENTIRE sync brain, all four rows (see SyncPlan.h). Pure
        // function: no network, no files — the test IS the table.
        using sync::Action;
        using sync::decide;
        QCOMPARE(decide(5, 5, false), Action::Nothing);  // nobody moved
        QCOMPARE(decide(5, 5, true),  Action::Push);     // only we did
        QCOMPARE(decide(7, 5, false), Action::Pull);     // only server did
        QCOMPARE(decide(7, 5, true),  Action::Conflict); // both — a human decides
    }

    void perAccountPathsAreDistinctAndCaseInsensitive()
    {
        // Each account maps to its own file; an empty user falls back to the
        // legacy global path (so tests/tools that pass no user are unchanged).
        const QString global = JsonStore::filePathForUser(QString());
        QVERIFY(global.endsWith("data.json"));

        const QString a = JsonStore::filePathForUser("phanperry");
        const QString b = JsonStore::filePathForUser("alice");
        QVERIFY(a != b);
        QVERIFY(a != global);
        QVERIFY(a.endsWith("data-phanperry.json"));

        // "Alice" and "alice" are one account → one file (server agrees).
        QCOMPARE(JsonStore::filePathForUser("Alice"),
                 JsonStore::filePathForUser("alice"));
    }

    void adoptionTransfersOldDataOnceThenLeavesOthersFresh()
    {
        // The migration the owner asked for, proven end to end. We drive the
        // REAL paths (JsonStore::defaultFilePath / filePathForUser) rather
        // than hand-built ones — QStandardPaths resolves at process start, so
        // second-guessing it in the test is how the first draft went wrong.
        // Unique usernames keep this hermetic without touching real accounts.
        const QString userA = "mig_first_" + uniq();
        const QString userB = "mig_second_" + uniq();
        const QString globalPath = JsonStore::defaultFilePath();
        const QString backupPath = globalPath + ".pre-accounts.bak";

        // Save/restore whatever real global file might exist, so the test
        // never eats a developer's actual data.json.
        const bool hadGlobal = QFile::exists(globalPath);
        const QString stash = globalPath + ".test-stash";
        if (hadGlobal) { QFile::remove(stash); QFile::rename(globalPath, stash); }
        auto cleanup = qScopeGuard([&] {
            QFile::remove(JsonStore::filePathForUser(userA));
            QFile::remove(JsonStore::filePathForUser(userB));
            QFile::remove(globalPath);
            QFile::remove(backupPath);
            if (hadGlobal) QFile::rename(stash, globalPath);
        });

        // Seed a recognisable "old" planner at the global path.
        {
            AppData old;
            const QString cat = old.addCategory("Old Work", QColor("#4C6FE0"));
            old.addActivity("Legacy Study", cat);
            QVERIFY(JsonStore(globalPath).save(old));
        }
        QVERIFY(QFile::exists(globalPath));

        // First user logs in → adopts the global file, data intact.
        QVERIFY(JsonStore::adoptGlobalDataForUser(userA));
        AppData adopted;
        QVERIFY(JsonStore(JsonStore::filePathForUser(userA)).load(adopted));
        QCOMPARE(adopted.categories().size(), 1);
        QCOMPARE(adopted.categories().first().name, QString("Old Work"));

        // The global file was retired to a backup — nothing destroyed.
        QVERIFY(!QFile::exists(globalPath));
        QVERIFY(QFile::exists(backupPath));

        // A SECOND user finds nothing to adopt → starts fresh (no file).
        QVERIFY(!JsonStore::adoptGlobalDataForUser(userB));
        QVERIFY(!QFile::exists(JsonStore::filePathForUser(userB)));

        // Re-running adoption for the first user is a no-op — their file
        // already exists, so their data is never clobbered by a re-run.
        QVERIFY(!JsonStore::adoptGlobalDataForUser(userA));
    }

private:
    static QString uniq()
    {
        return QString::number(
            QDateTime::currentMSecsSinceEpoch() % 1000000);
    }
};

QTEST_MAIN(TestAuth)
#include "test_auth.moc"
